@echo off
setlocal
cd /d "%~dp0"

if not exist .venv (
  echo Creating venv...
  python -m venv .venv
)

call .venv\Scripts\activate.bat

if not exist .venv\.deps_installed (
  echo Installing dependencies...
  python -m pip install --upgrade pip >nul
  python -m pip install -r requirements.txt
  type nul > .venv\.deps_installed
) else (
  for %%I in (requirements.txt) do for %%J in (.venv\.deps_installed) do (
    if %%~tI GTR %%~tJ (
      echo Updating dependencies...
      python -m pip install -r requirements.txt
      type nul > .venv\.deps_installed
    )
  )
)

python -m app %*
endlocal
