// SocketIO progress listener + upload card rendering.
// Exposes window.NvftpProgress { register, isPaused, isStopped, errorBanner, note }.

(function () {
  'use strict';
  const list  = document.getElementById('uploads-list');
  const tmpl  = document.getElementById('upload-card-tmpl');
  const cards = new Map();   // upload_id -> {root, state}
  const states = new Map();  // upload_id -> { paused, stopped, filename, total_bytes, samples: [{t, bytes}] }

  // Rolling-window speed estimate. The server's per-event speed_bps is a 0.5 s
  // snapshot and jitters wildly on 16 MiB chunks at WAN latency, so we recompute
  // here over a 5 s window — much smoother and survives the occasional 0 tick.
  const WINDOW_MS = 5000;
  const MIN_SAMPLES_MS = 1500;    // need ≥1.5 s of data before reporting

  function pushSample(st, bytes) {
    const now = performance.now();
    st.samples = st.samples || [];
    st.samples.push({ t: now, b: bytes });
    const cutoff = now - WINDOW_MS;
    while (st.samples.length > 1 && st.samples[0].t < cutoff) st.samples.shift();
  }
  function windowSpeed(st) {
    if (!st.samples || st.samples.length < 2) return null;
    const first = st.samples[0];
    const last  = st.samples[st.samples.length - 1];
    const dt = (last.t - first.t) / 1000;
    if (dt < MIN_SAMPLES_MS / 1000) return null;
    const db = last.b - first.b;
    if (db <= 0) return 0;
    return db / dt;
  }

  function ensureCard(id, meta) {
    if (cards.has(id)) return cards.get(id);
    const node = tmpl.content.firstElementChild.cloneNode(true);
    node.dataset.id = id;
    node.querySelector('.pkg-progress-name').textContent = meta.filename || id.slice(0,8);
    if (meta.target_folder) {
      const t = node.querySelector('.pkg-progress-target');
      t.textContent = '→ ' + meta.target_folder + '/';
      t.title = 'Writing to ' + meta.target_folder + '/ on both endpoints';
    }
    list.querySelector('.empty-state')?.remove();
    list.prepend(node);

    node.querySelector('.act-pause').addEventListener('click',  () => action(id, 'pause'));
    node.querySelector('.act-resume').addEventListener('click', () => action(id, 'resume'));
    node.querySelector('.act-stop').addEventListener('click',   () => {
      if (!confirm('Stop this upload? Partial bytes stay on the SFTP server so you can Resume later.')) return;
      action(id, 'stop');
    });
    node.querySelector('.act-kill').addEventListener('click', () => {
      const st = states.get(id) || {};
      const name = st.filename || id.slice(0, 8);
      const isComplete = st.status === 'complete';
      const prompt = isComplete
        ? `Close "${name}" from the activity list?\n\nThe uploaded file STAYS on the SFTP server. This only dismisses the card.`
        : `Kill upload "${name}"?\n\nThis will delete the partial file from BOTH SFTP endpoints and remove the session. This cannot be undone.`;
      if (!confirm(prompt)) return;
      fetch(`/api/uploads/${id}`, { method: 'DELETE' })
        .then(r => r.json())
        .then(j => {
          if (j.error) { alert((isComplete ? 'Close' : 'Kill') + ' failed: ' + j.error); return; }
          cards.get(id)?.root.remove();
          cards.delete(id);
          states.delete(id);
          if (!list.querySelector('.upload-card')) {
            const empty = document.createElement('div');
            empty.className = 'empty-state';
            empty.textContent = 'No active uploads.';
            list.appendChild(empty);
          }
        })
        .catch(err => alert((isComplete ? 'Close' : 'Kill') + ' failed: ' + err.message));
    });
    const card = { root: node };
    cards.set(id, card);
    return card;
  }

  function action(id, what) {
    fetch(`/api/uploads/${id}/${what}`, { method: 'POST' })
      .catch(err => console.error('action error', err));
    const st = states.get(id) || {};
    if (what === 'pause') st.paused = true;
    if (what === 'resume') st.paused = false;
    if (what === 'stop')   st.stopped = true;
    states.set(id, st);
  }

  function fmtBytes(n) {
    if (n == null) return '';
    if (n < 1024) return n + ' B';
    if (n < 1024*1024) return (n/1024).toFixed(1) + ' KB';
    if (n < 1024*1024*1024) return (n/1024/1024).toFixed(1) + ' MB';
    return (n/1024/1024/1024).toFixed(2) + ' GB';
  }
  function fmtSpeed(bps) {
    if (!bps) return '';
    if (bps < 1024) return bps.toFixed(0) + ' B/s';
    if (bps < 1024*1024) return (bps/1024).toFixed(1) + ' KB/s';
    return (bps/1024/1024).toFixed(2) + ' MB/s';
  }
  function fmtEta(remaining, bps) {
    if (!remaining || !bps) return '';
    const sec = Math.round(remaining / bps);
    if (sec < 60) return sec + 's';
    if (sec < 3600) return Math.floor(sec/60)+'m '+(sec%60)+'s';
    return Math.floor(sec/3600)+'h '+Math.floor((sec%3600)/60)+'m';
  }

  function render(p) {
    if (p.status === 'killed') {
      cards.get(p.upload_id)?.root.remove();
      cards.delete(p.upload_id);
      states.delete(p.upload_id);
      if (!list.querySelector('.upload-card')) {
        const empty = document.createElement('div');
        empty.className = 'empty-state';
        empty.textContent = 'No active uploads.';
        list.appendChild(empty);
      }
      return;
    }
    const card = ensureCard(p.upload_id, { filename: p.filename, target_folder: p.target_folder });
    const r = card.root;
    // Keep the target label in sync if the row was preloaded from /api/uploads on page load.
    if (p.target_folder) {
      const t = r.querySelector('.pkg-progress-target');
      if (t && !t.textContent) t.textContent = '→ ' + p.target_folder + '/';
    }
    const st = states.get(p.upload_id) || {};

    // Build/refresh the rolling speed window.
    if (p.status === 'uploading') {
      pushSample(st, p.bytes_done);
    } else {
      // Pause/stop/error: clear samples so resume starts fresh.
      st.samples = [];
    }
    const smoothed = windowSpeed(st);

    const pct = p.total_bytes ? Math.min(100, (p.bytes_done / p.total_bytes) * 100) : null;
    r.querySelector('.pkg-progress-pct').textContent = pct == null ? '—' : pct.toFixed(1) + '%';
    r.querySelector('.pkg-progress-bar').style.width = (pct == null ? 20 : pct) + '%';
    r.querySelector('.pkg-progress-bytes').textContent =
      fmtBytes(p.bytes_done) + (p.total_bytes ? ' / ' + fmtBytes(p.total_bytes) : '');

    const speedEl = r.querySelector('.pkg-progress-speed');
    const etaEl   = r.querySelector('.pkg-progress-eta');
    if (p.status === 'uploading') {
      if (smoothed == null) {
        speedEl.textContent = '↑ calculating…';
        etaEl.textContent   = '⏱ —';
      } else {
        speedEl.textContent = '↑ ' + fmtSpeed(smoothed);
        etaEl.textContent   = p.total_bytes
          ? '⏱ ' + fmtEta(p.total_bytes - p.bytes_done, smoothed)
          : '';
      }
    } else if (p.status === 'paused') {
      speedEl.textContent = '↑ paused';
      etaEl.textContent   = '';
    } else if (p.status === 'complete') {
      speedEl.textContent = '✓ done';
      etaEl.textContent   = '';
    } else {
      speedEl.textContent = '';
      etaEl.textContent   = '';
    }

    const statusEl = r.querySelector('.pkg-progress-status');
    statusEl.textContent = p.status;
    statusEl.className = 'pkg-progress-status status-' + p.status;
    const bar = r.querySelector('.pkg-progress-bar');
    bar.classList.toggle('done',  p.status === 'complete');
    bar.classList.toggle('error', p.status === 'failed' || p.status === 'corrupt');

    const pauseBtn  = r.querySelector('.act-pause');
    const resumeBtn = r.querySelector('.act-resume');
    const stopBtn   = r.querySelector('.act-stop');
    const killBtn   = r.querySelector('.act-kill');
    const isTerminal = ['complete','failed','corrupt'].includes(p.status);
    pauseBtn.style.display  = (p.status === 'uploading') ? '' : 'none';
    resumeBtn.style.display = (p.status === 'paused' || p.status === 'failed') ? '' : 'none';
    stopBtn.style.display   = isTerminal ? 'none' : '';
    stopBtn.disabled = p.status === 'paused';
    if (killBtn) {
      killBtn.style.display = '';
      if (p.status === 'complete') {
        killBtn.textContent = 'Close';
        killBtn.title = 'Dismiss this card. The uploaded file stays on the SFTP server.';
        killBtn.classList.remove('btn-danger');
        killBtn.classList.add('btn-secondary');
      } else if (isTerminal) {
        // failed / corrupt — partial probably still on the server, treat as Kill.
        killBtn.textContent = 'Discard';
        killBtn.title = 'Delete the partial file from both endpoints and dismiss.';
        killBtn.classList.add('btn-danger');
        killBtn.classList.remove('btn-secondary');
      } else {
        killBtn.textContent = 'Kill';
        killBtn.title = 'Delete the partial file from both endpoints and discard this session.';
        killBtn.classList.add('btn-danger');
        killBtn.classList.remove('btn-secondary');
      }
    }

    if (p.status === 'complete') {
      const sb = r.querySelector('.sha-badge');
      sb.textContent = 'SHA-256 OK';
      sb.className = 'sha-badge ok';
      maybeNotify(p.filename + ' completed');
    } else if (p.status === 'corrupt') {
      const sb = r.querySelector('.sha-badge');
      sb.textContent = 'SHA-256 MISMATCH';
      sb.className = 'sha-badge bad';
    } else if (p.status === 'failed' && p.error) {
      const sb = r.querySelector('.sha-badge');
      sb.textContent = p.error;
      sb.className = 'sha-badge bad';
    }

    st.paused  = (p.status === 'paused');
    st.stopped = (p.status === 'complete' || p.status === 'failed' || p.status === 'corrupt');
    st.status  = p.status;
    st.filename = p.filename;
    st.total_bytes = p.total_bytes;
    states.set(p.upload_id, st);
  }

  function maybeNotify(text) {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'granted') new Notification('nvftp-sync', { body: text });
    else if (Notification.permission !== 'denied') Notification.requestPermission();
  }

  window.NvftpProgress = {
    register(uploadId, meta) {
      ensureCard(uploadId, meta);
      states.set(uploadId, { paused: false, stopped: false, ...meta });
    },
    isPaused(id)  { return !!(states.get(id) || {}).paused; },
    isStopped(id) { return !!(states.get(id) || {}).stopped; },
    errorBanner(id, msg) {
      const card = ensureCard(id, {});
      const sb = card.root.querySelector('.sha-badge');
      sb.textContent = msg;
      sb.className = 'sha-badge bad';
    },
    note(id, msg) {
      const card = ensureCard(id, {});
      card.root.querySelector('.pkg-progress-status').textContent = msg;
    },
  };

  // Bootstrap: pull any active uploads from server so the page survives reloads.
  fetch('/api/uploads?limit=50').then(r => r.json()).then(rows => {
    rows.filter(r => !['complete'].includes(r.status))
        .reverse()
        .forEach(r => render({
          upload_id: r.id, filename: r.filename, status: r.status,
          bytes_done: r.bytes_done, total_bytes: r.total_bytes,
          speed_bps: 0, error: r.error_message,
        }));
  }).catch(() => {});

  // Live updates.
  const socket = io();
  socket.on('upload:progress', render);

  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
})();
