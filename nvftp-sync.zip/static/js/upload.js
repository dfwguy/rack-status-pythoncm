// Browser-side chunked upload + URL-pull form handler.

(function () {
  'use strict';
  const CHUNK = (window.NVFTP_CONFIG && window.NVFTP_CONFIG.chunkSize) || (16 * 1024 * 1024);
  const RETRY_INITIAL_DELAY = 1000;   // ms
  const RETRY_MAX_DELAY     = 60_000; // ms

  // ── Tab switching ───────────────────────────────────────────────
  document.querySelectorAll('.tab').forEach(t => {
    t.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
      t.classList.add('active');
      document.querySelectorAll('.tab-panel').forEach(p => p.hidden = (p.dataset.tabPanel !== t.dataset.tab));
    });
  });

  // ── Helpers ─────────────────────────────────────────────────────
  function buildTarget(selectId, subInputId) {
    const top = document.getElementById(selectId).value;
    const sub = (document.getElementById(subInputId).value || '').trim().replace(/^\/+|\/+$/g, '');
    return sub ? `${top}/${sub}` : top;
  }

  async function postJSON(url, body) {
    const r = await fetch(url, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) });
    if (r.status === 409) {
      const j = await r.json();
      const choice = await askConflict(body.filename || body.url || 'file', j.existing);
      if (!choice) throw new Error('cancelled');
      return postJSON(url, { ...body, on_conflict: choice });
    }
    if (!r.ok) throw new Error((await r.json().catch(()=>({}))).error || r.statusText);
    return r.json();
  }

  function askConflict(name, info) {
    return new Promise(resolve => {
      const modal = document.createElement('div');
      modal.className = 'modal-backdrop';
      const fmtBytes = n => {
        if (n == null) return '—';
        if (n < 1024) return n + ' B';
        if (n < 1024*1024) return (n/1024).toFixed(1) + ' KB';
        if (n < 1024*1024*1024) return (n/1024/1024).toFixed(1) + ' MB';
        return (n/1024/1024/1024).toFixed(2) + ' GB';
      };
      const where = [];
      if (info?.base?.exists)   where.push(`base (${fmtBytes(info.base.size)})`);
      if (info?.remote?.exists) where.push(`remote (${fmtBytes(info.remote.size)})`);
      modal.innerHTML = `
        <div class="modal-card">
          <div class="modal-title">File already exists</div>
          <div class="modal-body">
            <code>${name}</code> is already on ${where.join(' and ')}.
            <br><br>How do you want to proceed?
          </div>
          <div class="modal-actions">
            <button class="btn btn-sm btn-secondary" data-c="">Cancel</button>
            <button class="btn btn-sm btn-secondary" data-c="rename">Auto-rename</button>
            <button class="btn btn-sm btn-danger" data-c="overwrite">Replace</button>
          </div>
        </div>`;
      document.body.appendChild(modal);
      modal.addEventListener('click', e => {
        if (e.target.dataset.c !== undefined) {
          const choice = e.target.dataset.c;
          modal.remove();
          resolve(choice || null);
        } else if (e.target === modal) {
          modal.remove();
          resolve(null);
        }
      });
    });
  }

  // ── Local file upload ───────────────────────────────────────────
  const dropZone = document.getElementById('drop-zone');
  const picker   = document.getElementById('file-picker');

  ['dragenter','dragover'].forEach(ev =>
    dropZone.addEventListener(ev, e => { e.preventDefault(); dropZone.classList.add('drag'); }));
  ['dragleave','drop'].forEach(ev =>
    dropZone.addEventListener(ev, e => { e.preventDefault(); dropZone.classList.remove('drag'); }));

  dropZone.addEventListener('drop', e => {
    const files = [...(e.dataTransfer.files || [])];
    files.forEach(startBrowserUpload);
  });
  picker.addEventListener('change', () => {
    [...picker.files].forEach(startBrowserUpload);
    picker.value = '';
  });

  async function startBrowserUpload(file) {
    const target = buildTarget('local-target-folder', 'local-subfolder');
    try {
      const created = await postJSON('/api/uploads', {
        filename: file.name,
        target_folder: target,
        total_bytes: file.size,
      });
      const shownName = created.filename || file.name;
      window.NvftpProgress.register(created.upload_id,
        { filename: shownName, target_folder: target, total_bytes: file.size });
      runBrowserUpload(created.upload_id, file).catch(err => {
        console.error(err);
        window.NvftpProgress.errorBanner(created.upload_id, err.message || String(err));
      });
    } catch (e) {
      if (e.message !== 'cancelled') alert('Failed to start upload: ' + e.message);
    }
  }

  async function runBrowserUpload(uploadId, file) {
    const hasher = new window.NvftpSha256();
    let offset = 0;
    let retryDelay = RETRY_INITIAL_DELAY;

    while (offset < file.size) {
      // Pause: yield control to a controller flag.
      while (window.NvftpProgress.isPaused(uploadId)) {
        await sleep(300);
      }
      if (window.NvftpProgress.isStopped(uploadId)) return;

      const end   = Math.min(offset + CHUNK, file.size);
      const blob  = file.slice(offset, end);
      const buf   = await blob.arrayBuffer();
      try {
        const r = await fetch('/api/chunk', {
          method: 'POST',
          headers: { 'X-Upload-Id': uploadId, 'X-Offset': String(offset), 'Content-Type': 'application/octet-stream' },
          body: buf,
        });
        if (r.status === 409) {
          const j = await r.json();
          // Server is at a different offset (e.g. after a resume).
          offset = j.server_offset || 0;
          // Reset hasher and re-read; can't help — we lost prior bytes' hash.
          // Mark hash as disabled for this upload.
          hasher.disabled = true;
          continue;
        }
        if (!r.ok) {
          throw new Error((await r.json().catch(()=>({}))).error || r.statusText);
        }
        if (!hasher.disabled) hasher.update(new Uint8Array(buf));
        offset = end;
        retryDelay = RETRY_INITIAL_DELAY;
      } catch (e) {
        // Network blip — retry with exponential backoff.
        console.warn('Chunk error, retrying in', retryDelay, 'ms', e);
        window.NvftpProgress.note(uploadId, `retrying… (${e.message || e})`);
        await sleep(retryDelay);
        retryDelay = Math.min(retryDelay * 2, RETRY_MAX_DELAY);
      }
    }
    // Finalize
    const finalSha = hasher.disabled ? '' : hasher.hex();
    await postJSON(`/api/uploads/${uploadId}/finalize`, { sha256: finalSha });
  }

  // ── URL pull ────────────────────────────────────────────────────
  document.getElementById('btn-pull').addEventListener('click', async () => {
    const errEl = document.getElementById('url-error');
    errEl.style.display = 'none';
    const target = buildTarget('url-target-folder', 'url-subfolder');
    const urls = (document.getElementById('url-list').value || '')
      .split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    if (!urls.length) { errEl.textContent = 'Enter at least one URL.'; errEl.style.display = 'block'; return; }
    for (const url of urls) {
      try {
        const fallbackName = url.split('/').pop() || 'download.bin';
        const r = await postJSON('/api/url-pull', {
          url, target_folder: target, verify_tls: false, filename: fallbackName,
        });
        const filename = r.filename || fallbackName;
        window.NvftpProgress.register(r.upload_id,
          { filename, target_folder: target, total_bytes: null });
      } catch (e) {
        if (e.message === 'cancelled') continue;
        errEl.textContent = `${url}: ${e.message}`;
        errEl.style.display = 'block';
        break;
      }
    }
  });

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
})();
