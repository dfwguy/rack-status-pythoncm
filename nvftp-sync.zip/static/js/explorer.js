// Merged file explorer for the two SFTP endpoints.
(function () {
  'use strict';
  const wrap    = document.querySelector('.explorer');
  const tbody   = document.getElementById('exp-body');
  const crumb   = document.getElementById('exp-breadcrumb');
  const errEl   = document.getElementById('exp-error');
  const refresh = document.getElementById('exp-refresh');
  const cacheAge = document.getElementById('exp-cache-age');

  let curPath = '';
  let lastSyncedAt = 0;        // wall-clock unix seconds when the index was last refreshed
  let lastFromIndex = false;   // was the response served from the persistent index?

  function fmtBytes(n) {
    if (n == null) return '—';
    if (n < 1024) return n + ' B';
    if (n < 1024*1024) return (n/1024).toFixed(1) + ' KB';
    if (n < 1024*1024*1024) return (n/1024/1024).toFixed(1) + ' MB';
    return (n/1024/1024/1024).toFixed(2) + ' GB';
  }
  function fmtMtime(t) {
    if (!t) return '—';
    const d = new Date(t * 1000);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
  function syncBadge(s) {
    const map = {
      ok:             ['✓',      'sync-ok',    'In sync on base + remote'],
      base_only:      ['⚠ base', 'sync-warn',  'Missing on remote endpoint'],
      remote_only:    ['⚠ remote','sync-warn', 'Missing on base endpoint'],
      size_mismatch:  ['⚠ size', 'sync-bad',   'Different sizes on base vs remote'],
      type_mismatch:  ['⚠ type', 'sync-bad',   'One side is a file, the other is a directory'],
      missing:        ['—',      'sync-mute',  'Neither side has this entry'],
    };
    const [text, cls, tip] = map[s] || [s, 'sync-mute', s];
    return `<span class="sync-badge ${cls}" title="${tip}">${text}</span>`;
  }

  function renderCrumb(path) {
    const parts = path ? path.split('/') : [];
    let html = `<a href="#" data-path="">root</a>`;
    let acc = '';
    parts.forEach((p, i) => {
      acc = acc ? acc + '/' + p : p;
      html += ` <span class="crumb-sep">/</span> <a href="#" data-path="${acc}">${p}</a>`;
    });
    crumb.innerHTML = html;
    crumb.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', e => { e.preventDefault(); load(a.dataset.path); });
    });
  }

  function renderRows(res) {
    if (!res.entries.length) {
      tbody.innerHTML = `<tr><td colspan="4" class="explorer-empty">(empty)</td></tr>`;
      return;
    }
    const html = [];
    if (res.path) {
      html.push(`<tr class="up-row"><td colspan="4"><a href="#" data-up="${res.parent || ''}">⬆ ..</a></td></tr>`);
    }
    for (const e of res.entries) {
      const ref = e.base.exists ? e.base : e.remote;
      const sizeCell = e.type === 'dir' ? '—' : fmtBytes(ref.size);
      const mtimeCell = fmtMtime(ref.mtime);
      const nameCell = e.type === 'dir'
        ? `<a href="#" data-enter="${res.path ? res.path + '/' + e.name : e.name}">📁 ${e.name}/</a>`
        : `<span class="file-name">📄 ${e.name}</span>`;
      const mismatchDetail = e.sync === 'size_mismatch'
        ? `<span class="mismatch-detail" title="base ${fmtBytes(e.base.size)} ↔ remote ${fmtBytes(e.remote.size)}"></span>`
        : '';
      html.push(`
        <tr class="row-${e.sync}">
          <td class="col-name">${nameCell}</td>
          <td class="col-size">${sizeCell}${mismatchDetail}</td>
          <td class="col-mtime">${mtimeCell}</td>
          <td class="col-sync">${syncBadge(e.sync)}</td>
        </tr>
      `);
    }
    tbody.innerHTML = html.join('');
    tbody.querySelectorAll('a[data-enter]').forEach(a => {
      a.addEventListener('click', e => { e.preventDefault(); load(a.dataset.enter); });
    });
    tbody.querySelectorAll('a[data-up]').forEach(a => {
      a.addEventListener('click', e => { e.preventDefault(); load(a.dataset.up); });
    });
  }

  function fmtAge(seconds) {
    if (seconds < 1)   return 'just now';
    if (seconds < 60)  return Math.round(seconds) + 's ago';
    if (seconds < 3600) return Math.floor(seconds/60) + 'm ago';
    return Math.floor(seconds/3600) + 'h ' + Math.floor((seconds%3600)/60) + 'm ago';
  }
  function showAge() {
    if (!lastSyncedAt) { cacheAge.textContent = ''; return; }
    const age = (Date.now()/1000) - lastSyncedAt;
    let cls = '';
    if (age < 10)            cls = 'fresh';
    else if (age > 15 * 60)  cls = 'stale';
    cacheAge.className = 'cache-age ' + cls;
    const src = lastFromIndex ? 'synced' : 'live';
    cacheAge.textContent = src + ' ' + fmtAge(age);
  }

  let inflight = false;
  async function load(path, { force = false } = {}) {
    if (inflight) return;
    inflight = true;
    errEl.style.display = 'none';
    wrap.classList.add('loading');
    // Only show the "Loading…" placeholder on the first ever load — keeps the
    // table stable when refreshing.
    if (!tbody.querySelector('tr:not(.explorer-empty)')) {
      tbody.innerHTML = `<tr><td colspan="4" class="explorer-empty">Loading…</td></tr>`;
    }
    try {
      const params = new URLSearchParams({ path: path || '' });
      if (force) params.set('refresh', '1');
      const r = await fetch('/api/files?' + params.toString());
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || r.statusText);
      curPath = j.path || '';
      lastSyncedAt  = j.synced_at || ((Date.now()/1000) - (j.age_seconds || 0));
      lastFromIndex = !!j.from_index;
      renderCrumb(curPath);
      renderRows(j);
      showAge();
    } catch (e) {
      errEl.textContent = 'Failed to list: ' + e.message;
      errEl.style.display = 'block';
      tbody.innerHTML = '';
    } finally {
      inflight = false;
      wrap.classList.remove('loading');
    }
  }

  refresh.addEventListener('click', () => load(curPath, { force: true }));

  // Auto-refresh when an upload completes — surfaces the new file immediately.
  if (window.io) {
    const sock = window.__nvftpExplorerSocket || io();
    window.__nvftpExplorerSocket = sock;
    sock.on('upload:progress', p => {
      if (p.status === 'complete' || p.status === 'killed') {
        // Only refresh if we're viewing a path the upload would touch.
        load(curPath);
      }
    });
  }

  load('');
})();
