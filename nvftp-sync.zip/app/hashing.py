"""Tiny incremental SHA-256 wrapper kept distinct from hashlib so callers don't import directly."""
from __future__ import annotations

import hashlib


class IncrementalSha256:
    __slots__ = ("_h",)

    def __init__(self) -> None:
        self._h = hashlib.sha256()

    def update(self, data: bytes) -> None:
        if data:
            self._h.update(data)

    def hexdigest(self) -> str:
        return self._h.hexdigest()
