"""Flask + SocketIO app factory."""
from __future__ import annotations

import logging
import os
from pathlib import Path

from flask import Flask
from flask_socketio import SocketIO

from app import db
from app.config import Config

log = logging.getLogger(__name__)

PROJECT_DIR = Path(__file__).resolve().parent.parent


def create_app(cfg: Config) -> tuple[Flask, SocketIO]:
    db.init_db()
    recovered = db.recover_crashed_on_startup()
    if recovered:
        log.info("Recovered %d upload(s) from crash on startup", recovered)

    app = Flask(
        __name__,
        static_folder=str(PROJECT_DIR / "static"),
        template_folder=str(PROJECT_DIR / "templates"),
    )
    app.config["SECRET_KEY"] = os.urandom(24)
    app.config["MAX_CONTENT_LENGTH"] = None  # No global limit; large chunks supported.
    app.config["NVFTP_CONFIG"] = cfg

    socketio = SocketIO(app, async_mode="threading", cors_allowed_origins="*", max_http_buffer_size=10**9)

    # Persistent SFTP listing index + background syncer.
    from app.fs_index import FsIndex
    from app.fs_sync import FsSyncer
    fs_index = FsIndex(PROJECT_DIR / "data" / "fs_index.sqlite")
    app.config["NVFTP_FS_INDEX"] = fs_index

    # Late import to avoid circular dep (api.py also imports from app).
    from app.routes.api import _fetch_listing
    fs_syncer = FsSyncer(cfg, fs_index, fetch_listing=_fetch_listing)
    app.config["NVFTP_FS_SYNCER"] = fs_syncer
    fs_syncer.start()

    # Upload manager — broadcasts progress over Socket.IO.
    from app.upload_manager import UploadManager

    def _broadcast(payload: dict) -> None:
        socketio.emit("upload:progress", payload)

    def _invalidate_listing(parent_folder: str) -> None:
        # Drop stale entries and ask the syncer to refresh promptly.
        fs_index.invalidate_prefix(parent_folder or "")
        fs_syncer.request_refresh(parent_folder or "")

    manager = UploadManager(cfg, on_progress=_broadcast,
                            on_filesystem_change=_invalidate_listing)
    app.config["NVFTP_MANAGER"] = manager

    # Register blueprints.
    from app.routes.pages import bp as pages_bp
    from app.routes.api import bp as api_bp
    from app.routes.events import register as register_events

    app.register_blueprint(pages_bp)
    app.register_blueprint(api_bp)
    register_events(socketio)

    @app.context_processor
    def _ctx():
        return {"allowed_folders": cfg.allowed_folders}

    return app, socketio
