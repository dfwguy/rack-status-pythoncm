"""YAML config loader with defaults, plus API-token bootstrap."""
from __future__ import annotations

import logging
import secrets
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_DIR / "data"
LOG_DIR = PROJECT_DIR / "logs"
API_TOKEN_FILE = DATA_DIR / ".api_token"

log = logging.getLogger(__name__)


@dataclass
class ServerCfg:
    host: str = "127.0.0.1"
    port: int = 5050
    auto_open_browser: bool = True
    api_token: str | None = None
    allow_loopback_no_auth: bool = True


@dataclass
class SftpCfg:
    host: str = "transfer.nvftp.nvidia.com"
    port: int = 22
    username: str = ""
    key_path: str = "~/.ssh/id_ed25519"
    key_passphrase: str | None = None
    strict_host_key_checking: bool = False
    known_hosts: str = "~/.ssh/known_hosts"


@dataclass
class EndpointsCfg:
    base: str = ""
    remote: str = ""


@dataclass
class UploadsCfg:
    max_concurrent: int = 3
    chunk_size: int = 16 * 1024 * 1024
    bandwidth_limit_kbps: int = 0
    auto_date_subfolder: bool = False
    free_space_preflight: bool = True
    # What to do when the target filename already exists on the SFTP server.
    #   'error'     — refuse and let the caller decide (default; browser shows a dialog)
    #   'overwrite' — delete the existing file on both endpoints and start fresh
    #   'rename'    — append a timestamped suffix (e.g. _2026-05-11_1845)
    on_conflict: str = "error"


@dataclass
class UrlPullCfg:
    trusted_skip_verify_hosts: list[str] = field(default_factory=list)
    connect_timeout: int = 10
    read_timeout: int = 60


@dataclass
class LoggingCfg:
    level: str = "INFO"
    file: str = "logs/app.log"


@dataclass
class Config:
    server: ServerCfg = field(default_factory=ServerCfg)
    sftp: SftpCfg = field(default_factory=SftpCfg)
    endpoints: EndpointsCfg = field(default_factory=EndpointsCfg)
    allowed_folders: list[str] = field(default_factory=lambda: ["btrfs", "ist", "perf", "diag"])
    uploads: UploadsCfg = field(default_factory=UploadsCfg)
    url_pull: UrlPullCfg = field(default_factory=UrlPullCfg)
    logging: LoggingCfg = field(default_factory=LoggingCfg)


def _merge(target: Any, raw: dict[str, Any] | None) -> None:
    if not raw:
        return
    for k, v in raw.items():
        if not hasattr(target, k):
            log.warning("Unknown config key: %s", k)
            continue
        cur = getattr(target, k)
        if hasattr(cur, "__dataclass_fields__"):
            _merge(cur, v)
        else:
            setattr(target, k, v)


def _ensure_api_token(cfg: Config) -> None:
    if cfg.server.api_token:
        return
    if API_TOKEN_FILE.exists():
        cfg.server.api_token = API_TOKEN_FILE.read_text().strip()
        return
    token = secrets.token_urlsafe(32)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    API_TOKEN_FILE.write_text(token + "\n")
    try:
        API_TOKEN_FILE.chmod(0o600)
    except (OSError, NotImplementedError):
        pass
    cfg.server.api_token = token
    log.info("Generated API token at %s", API_TOKEN_FILE)


def _configure_logging(cfg: Config) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_path = PROJECT_DIR / cfg.logging.file
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=getattr(logging, cfg.logging.level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler(), logging.FileHandler(log_path)],
    )


def load_config(path: Path | None = None) -> Config:
    candidate = path or (PROJECT_DIR / "config.yaml")
    cfg = Config()
    if candidate.exists():
        raw = yaml.safe_load(candidate.read_text()) or {}
        _merge(cfg, raw)
    else:
        log.warning("config.yaml not found; using defaults. Copy config.example.yaml to config.yaml.")
    _configure_logging(cfg)
    _ensure_api_token(cfg)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return cfg


def expand_path(p: str) -> Path:
    return Path(p).expanduser().resolve()
