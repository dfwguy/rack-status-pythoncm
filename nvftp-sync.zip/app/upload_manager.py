"""Per-upload state, worker threads, and the chunk-feeding queue.

States: queued → uploading → (paused | complete | failed | corrupt)

Each upload has its own worker thread that:
  - opens an SSH connection
  - prepares the two SFTP paths (resume offset / fresh start)
  - consumes chunks fed in via `feed_chunk()` (browser) or pulls them itself (URL)
  - persists progress to SQLite after every chunk
  - emits SocketIO progress events via a callback
"""
from __future__ import annotations

import logging
import queue
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from app import db
from app.config import Config
from app.hashing import IncrementalSha256
from app.sftp_pool import (
    ConflictError,
    DualWriter,
    SftpError,
    connect,
    is_safe_subpath,
    join_path,
    prepare_for_upload,
    preflight_free_space,
    remove_if_exists,
    stat_existing,
)

log = logging.getLogger(__name__)

ProgressCallback = Callable[[dict], None]

# Sentinels used in the chunk queue.
_END_SENTINEL = b""
_PAUSE_SENTINEL = object()
_STOP_SENTINEL = object()


@dataclass
class UploadHandle:
    upload_id: str
    source: str  # 'browser' | 'url' | 'local'
    filename: str
    target_folder: str  # e.g. 'btrfs/subdir'
    base_path: str
    remote_path: str
    total_bytes: Optional[int] = None
    bytes_done: int = 0
    status: str = "queued"
    chunk_q: "queue.Queue" = field(default_factory=lambda: queue.Queue(maxsize=8))
    sha_server: IncrementalSha256 = field(default_factory=IncrementalSha256)
    last_bytes_ts: float = 0.0
    last_bytes_done: int = 0
    speed_bps: float = 0.0
    thread: Optional[threading.Thread] = None
    error: Optional[str] = None
    metadata: dict = field(default_factory=dict)
    # URL-pull specific:
    url: Optional[str] = None
    verify_tls: bool = True
    # Local-file (server-side filesystem) specific:
    local_source: Optional[str] = None
    # Browser-upload offset acked back to the client.
    server_offset: int = 0
    # Optional client-supplied final hash (for browser uploads).
    sha_client_expected: Optional[str] = None
    pause_event: threading.Event = field(default_factory=threading.Event)
    stop_event: threading.Event = field(default_factory=threading.Event)


class UploadManager:
    def __init__(self, cfg: Config, on_progress: ProgressCallback,
                 on_filesystem_change: Callable[[str], None] | None = None) -> None:
        self.cfg = cfg
        self.on_progress = on_progress
        # Called with the target folder whenever the SFTP filesystem state
        # likely changed (file appeared, was renamed, was deleted). Used by
        # the route layer to invalidate cached listings.
        self.on_filesystem_change = on_filesystem_change or (lambda _f: None)
        self._handles: dict[str, UploadHandle] = {}
        self._lock = threading.RLock()
        self._sem = threading.BoundedSemaphore(cfg.uploads.max_concurrent)

    # ── lookup / list ────────────────────────────────────────────────────
    def get(self, upload_id: str) -> Optional[UploadHandle]:
        with self._lock:
            return self._handles.get(upload_id)

    def list_active(self) -> list[UploadHandle]:
        with self._lock:
            return [h for h in self._handles.values() if h.status in ("queued", "uploading", "paused")]

    # ── new upload (browser-chunk source) ────────────────────────────────
    def create_browser_upload(
        self,
        *,
        filename: str,
        target_folder: str,
        total_bytes: int,
        sha_client_expected: str | None = None,
        metadata: dict | None = None,
        on_conflict: str | None = None,
    ) -> UploadHandle:
        h = self._new_handle(
            source="browser",
            filename=filename,
            target_folder=target_folder,
            total_bytes=total_bytes,
            metadata=metadata or {},
        )
        self._resolve_conflict(h, on_conflict)
        h.sha_client_expected = sha_client_expected
        self._persist_new(h)
        self._spawn(h, runner=self._run_browser_upload)
        return h

    def create_url_pull(
        self,
        *,
        url: str,
        filename: str,
        target_folder: str,
        verify_tls: bool,
        metadata: dict | None = None,
        on_conflict: str | None = None,
    ) -> UploadHandle:
        h = self._new_handle(
            source="url",
            filename=filename,
            target_folder=target_folder,
            total_bytes=None,
            metadata=metadata or {},
        )
        self._resolve_conflict(h, on_conflict)
        h.url = url
        h.verify_tls = verify_tls
        self._persist_new(h)
        self._spawn(h, runner=self._run_url_pull)
        return h

    def create_local_file(
        self,
        *,
        local_source: str,
        filename: str,
        target_folder: str,
        metadata: dict | None = None,
        on_conflict: str | None = None,
    ) -> UploadHandle:
        p = Path(local_source).expanduser()
        if not p.is_file():
            raise SftpError(f"Local file not found: {p}")
        h = self._new_handle(
            source="local",
            filename=filename or p.name,
            target_folder=target_folder,
            total_bytes=p.stat().st_size,
            metadata=metadata or {},
        )
        self._resolve_conflict(h, on_conflict)
        h.local_source = str(p)
        self._persist_new(h)
        self._spawn(h, runner=self._run_local_file)
        return h

    # ── conflict resolution ──────────────────────────────────────────────
    def _resolve_conflict(self, h: UploadHandle, policy: str | None) -> None:
        """Apply on_conflict policy. May mutate h.filename / paths (rename),
        delete remote files (overwrite), or raise ConflictError ('error').

        Resume of an existing paused upload never goes through here — it uses
        _handle_from_row which keeps the original paths.
        """
        policy = (policy or self.cfg.uploads.on_conflict or "error").lower()
        if policy not in ("error", "overwrite", "rename"):
            raise SftpError(f"invalid on_conflict policy: {policy!r}")

        ssh = connect(self.cfg)
        try:
            info = stat_existing(ssh, h.base_path, h.remote_path)
            if not info["base"]["exists"] and not info["remote"]["exists"]:
                return
            if policy == "error":
                raise ConflictError(
                    f"{h.filename!r} already exists in {h.target_folder}/",
                    info,
                )
            if policy == "overwrite":
                remove_if_exists(ssh, [h.base_path, h.remote_path])
                db.audit(None, "conflict_overwrite",
                         {"target": h.target_folder, "filename": h.filename, "had": info})
                return
            if policy == "rename":
                self._rename_to_avoid(h, ssh)
                return
        finally:
            ssh.close()

    def _rename_to_avoid(self, h: UploadHandle, ssh) -> None:
        """Pick a filename that doesn't exist on EITHER endpoint, e.g.
        'foo.tbz' → 'foo_2026-05-11_1845.tbz' → 'foo_2026-05-11_1845-1.tbz' → ...
        """
        from datetime import datetime
        p = Path(h.filename)
        stem, suffix = p.stem, p.suffix
        ts = datetime.now().strftime("%Y-%m-%d_%H%M")
        base_dir_b = h.base_path[: -len(h.filename)].rstrip("/")
        base_dir_r = h.remote_path[: -len(h.filename)].rstrip("/")
        for attempt in range(50):
            cand = f"{stem}_{ts}{suffix}" if attempt == 0 else f"{stem}_{ts}-{attempt}{suffix}"
            cand_b = base_dir_b + "/" + cand
            cand_r = base_dir_r + "/" + cand
            info = stat_existing(ssh, cand_b, cand_r)
            if not info["base"]["exists"] and not info["remote"]["exists"]:
                db.audit(None, "conflict_rename",
                         {"from": h.filename, "to": cand, "target": h.target_folder})
                h.filename = cand
                h.base_path = cand_b
                h.remote_path = cand_r
                return
        raise SftpError("could not find a non-conflicting filename after 50 attempts")

    # ── browser actions ──────────────────────────────────────────────────
    def feed_chunk(self, upload_id: str, offset: int, data: bytes) -> int:
        h = self.get(upload_id)
        if not h:
            raise KeyError(upload_id)
        if h.source != "browser":
            raise SftpError("feed_chunk only valid for browser uploads")
        if h.status in ("complete", "failed", "corrupt"):
            raise SftpError(f"Upload is {h.status}; cannot accept chunks")
        if offset != h.server_offset:
            # Browser is out of sync; tell it the canonical offset.
            raise OffsetMismatch(h.server_offset)
        h.chunk_q.put(data, timeout=120)
        h.server_offset += len(data)
        return h.server_offset

    def finalize_browser(self, upload_id: str, sha_client_final: str) -> None:
        h = self.get(upload_id)
        if not h:
            raise KeyError(upload_id)
        h.sha_client_expected = sha_client_final
        h.chunk_q.put(_END_SENTINEL, timeout=120)

    def pause(self, upload_id: str) -> None:
        h = self.get(upload_id)
        if not h:
            raise KeyError(upload_id)
        h.pause_event.set()
        h.chunk_q.put(_PAUSE_SENTINEL, timeout=10)

    def resume(self, upload_id: str) -> UploadHandle:
        h = self.get(upload_id)
        if not h:
            # Recover from DB (post-restart resume).
            row = db.get_upload(upload_id)
            if not row:
                raise KeyError(upload_id)
            h = self._handle_from_row(row)
            with self._lock:
                self._handles[h.upload_id] = h
        h.pause_event.clear()
        h.stop_event.clear()
        if h.source == "browser":
            self._spawn(h, runner=self._run_browser_upload)
        elif h.source == "url":
            self._spawn(h, runner=self._run_url_pull)
        else:
            self._spawn(h, runner=self._run_local_file)
        return h

    def stop(self, upload_id: str) -> None:
        h = self.get(upload_id)
        if not h:
            raise KeyError(upload_id)
        h.stop_event.set()
        try:
            h.chunk_q.put_nowait(_STOP_SENTINEL)
        except queue.Full:
            pass

    def kill(self, upload_id: str) -> dict:
        """Cancel + drop the row; delete partial files unless the upload completed.

        - status='complete'  → just remove the DB row + dismiss the card.
                               The successfully uploaded file STAYS on the SFTP.
        - everything else    → cancel any worker, delete the partial from both
                               endpoints, remove the DB row.

        Idempotent: safe to call on terminal rows.
        """
        with self._lock:
            h = self._handles.get(upload_id)
            row = db.get_upload(upload_id)
        if not h and not row:
            raise KeyError(upload_id)

        current_status = (h.status if h else row.get("status")) if (h or row) else None

        # 1) tell any active worker to wind down
        if h:
            h.stop_event.set()
            try:
                h.chunk_q.put_nowait(_STOP_SENTINEL)
            except queue.Full:
                pass
            if h.thread and h.thread.is_alive():
                h.thread.join(timeout=5)

        deleted: list[str] = []
        errors: list[str] = []

        # 2) best-effort SFTP cleanup ONLY when the upload didn't complete.
        if current_status != "complete":
            base_path = h.base_path if h else row["base_path"]
            remote_path = h.remote_path if h else row["remote_path"]
            if base_path and remote_path:
                try:
                    ssh = connect(self.cfg)
                    try:
                        sftp = ssh.open_sftp()
                        for p in (base_path, remote_path):
                            try:
                                sftp.remove(p)
                                deleted.append(p)
                            except FileNotFoundError:
                                pass
                            except Exception as e:
                                errors.append(f"{p}: {e}")
                        sftp.close()
                    finally:
                        ssh.close()
                except Exception as e:
                    errors.append(f"connect: {e}")

        # 3) drop from memory + DB and emit a final 'killed' event for the UI
        with self._lock:
            self._handles.pop(upload_id, None)
        db.delete_upload(upload_id)
        db.audit(upload_id, "closed" if current_status == "complete" else "killed",
                 {"deleted": deleted, "errors": errors, "prior_status": current_status})
        # If we actually removed bytes from the filesystem, invalidate the listing.
        if deleted:
            target_folder = h.target_folder if h else (row.get("subfolder") or row.get("target_folder") or "")
            self.on_filesystem_change(target_folder)
        self.on_progress({
            "upload_id": upload_id,
            "filename": (h.filename if h else (row["filename"] if row else upload_id)),
            "status": "killed",   # UI key — removes the card
            "bytes_done": 0,
            "total_bytes": None,
            "speed_bps": 0,
            "error": None,
        })
        return {"deleted": deleted, "errors": errors, "files_kept": current_status == "complete"}

    # ── internals ────────────────────────────────────────────────────────
    def _new_handle(self, **kwargs) -> UploadHandle:
        upload_id = uuid.uuid4().hex
        target_folder = kwargs["target_folder"]
        if not is_safe_subpath(target_folder, self.cfg.allowed_folders):
            raise SftpError(f"Disallowed target folder: {target_folder!r}")
        filename = Path(kwargs["filename"]).name  # strip any directory component
        if not filename:
            raise SftpError("filename required")
        sub = target_folder
        if self.cfg.uploads.auto_date_subfolder:
            sub = f"{target_folder}/{datetime.now().strftime('%Y-%m-%d_%H%M')}"
        base_path = join_path(self.cfg.endpoints.base, sub, filename)
        remote_path = join_path(self.cfg.endpoints.remote, sub, filename)
        return UploadHandle(
            upload_id=upload_id,
            filename=filename,
            target_folder=sub,
            base_path=base_path,
            remote_path=remote_path,
            **{k: v for k, v in kwargs.items() if k not in ("filename", "target_folder")},
        )

    def _persist_new(self, h: UploadHandle) -> None:
        db.insert_upload(
            {
                "id": h.upload_id,
                "source": h.source,
                "filename": h.filename,
                "target_folder": h.target_folder,
                "subfolder": h.target_folder,
                "base_path": h.base_path,
                "remote_path": h.remote_path,
                "total_bytes": h.total_bytes,
                "bytes_done": 0,
                "status": "queued",
                "url": h.url,
                "local_source": h.local_source,
                "verify_tls": 1 if h.verify_tls else 0,
                "metadata": h.metadata,
            }
        )
        db.audit(h.upload_id, "created", {"source": h.source, "filename": h.filename})
        with self._lock:
            self._handles[h.upload_id] = h

    def _handle_from_row(self, row: dict) -> UploadHandle:
        h = UploadHandle(
            upload_id=row["id"],
            source=row["source"],
            filename=row["filename"],
            target_folder=row["subfolder"] or row["target_folder"],
            base_path=row["base_path"],
            remote_path=row["remote_path"],
            total_bytes=row["total_bytes"],
            bytes_done=row["bytes_done"] or 0,
            status=row["status"],
            url=row["url"],
            local_source=row["local_source"],
            verify_tls=bool(row["verify_tls"]),
        )
        h.server_offset = h.bytes_done
        return h

    def _spawn(self, h: UploadHandle, runner: Callable[[UploadHandle], None]) -> None:
        if h.thread and h.thread.is_alive():
            return
        t = threading.Thread(target=self._wrap, args=(h, runner), name=f"upload-{h.upload_id[:8]}", daemon=True)
        h.thread = t
        t.start()

    def _wrap(self, h: UploadHandle, runner: Callable[[UploadHandle], None]) -> None:
        with self._sem:
            try:
                runner(h)
            except Exception as e:
                log.exception("Upload %s failed", h.upload_id)
                h.error = str(e)
                # If we already wrote partial bytes to the SFTP endpoints, the
                # data is still good — drop to 'paused' so the user can Resume
                # rather than 'failed' (which is terminal).
                if h.bytes_done > 0:
                    h.status = "paused"
                    db.update_upload(h.upload_id, status="paused", error_message=str(e))
                    db.audit(h.upload_id, "paused_after_error", str(e))
                else:
                    h.status = "failed"
                    db.update_upload(h.upload_id, status="failed", error_message=str(e))
                    db.audit(h.upload_id, "failed", str(e))
                self._emit(h)

    # ── progress emit ────────────────────────────────────────────────────
    def _emit(self, h: UploadHandle) -> None:
        now = time.time()
        delta_t = now - (h.last_bytes_ts or now)
        if delta_t >= 0.5:
            delta_b = h.bytes_done - h.last_bytes_done
            h.speed_bps = delta_b / delta_t if delta_t > 0 else 0
            h.last_bytes_ts = now
            h.last_bytes_done = h.bytes_done
        self.on_progress(
            {
                "upload_id": h.upload_id,
                "filename": h.filename,
                "target_folder": h.target_folder,
                "source": h.source,
                "status": h.status,
                "bytes_done": h.bytes_done,
                "total_bytes": h.total_bytes,
                "speed_bps": round(h.speed_bps, 1),
                "error": h.error,
            }
        )

    def _maybe_throttle(self, h: UploadHandle, chunk_len: int, t_chunk_start: float) -> None:
        kbps = self.cfg.uploads.bandwidth_limit_kbps
        if not kbps:
            return
        elapsed = time.time() - t_chunk_start
        ideal = chunk_len / 1024.0 / kbps
        if ideal > elapsed:
            time.sleep(ideal - elapsed)

    # ── runners ──────────────────────────────────────────────────────────
    def _run_browser_upload(self, h: UploadHandle) -> None:
        h.status = "uploading"
        db.update_upload(h.upload_id, status="uploading")
        db.audit(h.upload_id, "uploading_start", {"resume_from": h.bytes_done})
        with self._open_writer(h, fresh=h.bytes_done == 0) as writer:
            h.server_offset = h.bytes_done  # reconciled offset
            self._emit(h)
            while True:
                if h.stop_event.is_set():
                    h.status = "paused"
                    db.update_upload(h.upload_id, status="paused")
                    db.audit(h.upload_id, "stopped_by_user")
                    self._emit(h)
                    return
                try:
                    item = h.chunk_q.get(timeout=60)
                except queue.Empty:
                    # No new chunks for 60s — flip to paused, keep partial.
                    h.status = "paused"
                    db.update_upload(h.upload_id, status="paused")
                    db.audit(h.upload_id, "auto_paused_idle")
                    self._emit(h)
                    return
                if item is _STOP_SENTINEL:
                    h.status = "paused"
                    db.update_upload(h.upload_id, status="paused")
                    db.audit(h.upload_id, "stopped_by_user")
                    self._emit(h)
                    return
                if item is _PAUSE_SENTINEL:
                    h.status = "paused"
                    db.update_upload(h.upload_id, status="paused")
                    db.audit(h.upload_id, "paused")
                    self._emit(h)
                    return
                if item == _END_SENTINEL:
                    writer.flush()
                    sha = h.sha_server.hexdigest()
                    expected = h.sha_client_expected
                    if expected and expected.lower() != sha.lower():
                        h.status = "corrupt"
                        h.error = f"client SHA={expected} server SHA={sha}"
                        db.update_upload(h.upload_id, status="corrupt", sha256_server=sha,
                                         sha256_client=expected, error_message=h.error)
                        db.audit(h.upload_id, "sha_mismatch", h.error)
                    else:
                        h.status = "complete"
                        db.update_upload(h.upload_id, status="complete", sha256_server=sha,
                                         sha256_client=expected, completed_at=db.now())
                        db.audit(h.upload_id, "completed", {"sha256": sha})
                    self.on_filesystem_change(h.target_folder)
                    self._emit(h)
                    return
                # normal chunk
                t0 = time.time()
                writer.write(item)
                h.sha_server.update(item)
                h.bytes_done += len(item)
                db.update_upload(h.upload_id, bytes_done=h.bytes_done)
                self._emit(h)
                self._maybe_throttle(h, len(item), t0)

    def _run_url_pull(self, h: UploadHandle) -> None:
        # Imported here to avoid a top-level dependency loop.
        from app.url_puller import pull
        h.status = "uploading"
        db.update_upload(h.upload_id, status="uploading")
        db.audit(h.upload_id, "uploading_start", {"resume_from": h.bytes_done, "url": h.url})
        # fresh=True for brand-new submissions (bytes_done == 0). For resume
        # of a paused row, bytes_done > 0 and we want the existing partial.
        with self._open_writer(h, fresh=h.bytes_done == 0) as writer:
            self._emit(h)

            def on_chunk(n: int, total: int | None, upstream_sha: str | None) -> bool:
                h.bytes_done += n
                if total and h.total_bytes is None:
                    h.total_bytes = total
                    db.update_upload(h.upload_id, total_bytes=total)
                db.update_upload(h.upload_id, bytes_done=h.bytes_done)
                self._emit(h)
                return not (h.stop_event.is_set() or h.pause_event.is_set())

            result = pull(
                url=h.url or "",
                writer=writer,
                start_offset=h.bytes_done,
                verify_tls=h.verify_tls,
                connect_timeout=self.cfg.url_pull.connect_timeout,
                read_timeout=self.cfg.url_pull.read_timeout,
                on_chunk=on_chunk,
                sha_state=h.sha_server,
            )
            writer.flush()
            if h.stop_event.is_set() or h.pause_event.is_set():
                h.status = "paused"
                db.update_upload(h.upload_id, status="paused")
                db.audit(h.upload_id, "paused")
                self._emit(h)
                return
            sha = h.sha_server.hexdigest()
            upstream = result.get("upstream_sha")
            mismatch = upstream and upstream.lower() != sha.lower()
            if mismatch:
                h.status = "corrupt"
                h.error = f"upstream SHA={upstream} server SHA={sha}"
                db.update_upload(h.upload_id, status="corrupt", sha256_server=sha,
                                 sha256_upstream=upstream, error_message=h.error)
                db.audit(h.upload_id, "sha_mismatch", h.error)
            else:
                h.status = "complete"
                db.update_upload(h.upload_id, status="complete", sha256_server=sha,
                                 sha256_upstream=upstream, completed_at=db.now())
                db.audit(h.upload_id, "completed", {"sha256": sha, "upstream_sha": upstream})
            self.on_filesystem_change(h.target_folder)
            self._emit(h)

    def _run_local_file(self, h: UploadHandle) -> None:
        h.status = "uploading"
        db.update_upload(h.upload_id, status="uploading")
        db.audit(h.upload_id, "uploading_start", {"resume_from": h.bytes_done, "src": h.local_source})
        chunk = self.cfg.uploads.chunk_size
        with self._open_writer(h, fresh=h.bytes_done == 0) as writer, open(h.local_source, "rb") as f:
            if h.bytes_done:
                f.seek(h.bytes_done)
            self._emit(h)
            while True:
                if h.stop_event.is_set() or h.pause_event.is_set():
                    h.status = "paused"
                    db.update_upload(h.upload_id, status="paused")
                    db.audit(h.upload_id, "paused")
                    self._emit(h)
                    return
                t0 = time.time()
                buf = f.read(chunk)
                if not buf:
                    break
                writer.write(buf)
                h.sha_server.update(buf)
                h.bytes_done += len(buf)
                db.update_upload(h.upload_id, bytes_done=h.bytes_done)
                self._emit(h)
                self._maybe_throttle(h, len(buf), t0)
            writer.flush()
            sha = h.sha_server.hexdigest()
            h.status = "complete"
            db.update_upload(h.upload_id, status="complete", sha256_server=sha, completed_at=db.now())
            db.audit(h.upload_id, "completed", {"sha256": sha})
            self.on_filesystem_change(h.target_folder)
            self._emit(h)

    # ── helpers ──────────────────────────────────────────────────────────
    def _open_writer(self, h: UploadHandle, *, fresh: bool):
        ssh = connect(self.cfg)
        # Reconcile offset on both ends:
        offset = prepare_for_upload(ssh, h.base_path, h.remote_path, fresh=fresh)
        if not fresh and offset != h.bytes_done:
            log.info(
                "Upload %s offset reconciled DB=%s SFTP=%s", h.upload_id, h.bytes_done, offset
            )
            h.bytes_done = offset
            db.update_upload(h.upload_id, bytes_done=offset)
            # Reset hash because we don't have the bytes prior to the new offset.
            h.sha_server = IncrementalSha256()
        if self.cfg.uploads.free_space_preflight and h.total_bytes:
            need = max(0, h.total_bytes - h.bytes_done)
            warn = preflight_free_space(ssh, [h.base_path, h.remote_path], need)
            if warn:
                ssh.close()
                raise SftpError(f"Insufficient free space: {warn}")
        writer = DualWriter(ssh, h.base_path, h.remote_path)
        # Wrap close to also close the SSH transport.
        orig_close = writer.close

        def _close_with_ssh():
            try:
                orig_close()
            finally:
                try:
                    ssh.close()
                except Exception:
                    pass
        writer.close = _close_with_ssh  # type: ignore[assignment]
        return writer


class OffsetMismatch(Exception):
    def __init__(self, server_offset: int) -> None:
        super().__init__(f"server offset is {server_offset}")
        self.server_offset = server_offset
