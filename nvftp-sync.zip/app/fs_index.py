"""SQLite-backed snapshot of SFTP directory listings.

Persisting the listings on disk means /api/files is instant in steady
state — the SSH+listdir cost only happens in the background syncer.
Each row stores the merged JSON payload for a path plus when it was
fetched and when it was last viewed (LRU signal for the syncer).
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Iterable


_SCHEMA = """
CREATE TABLE IF NOT EXISTS fs_cache (
  path        TEXT PRIMARY KEY,    -- '' for root, e.g. 'btrfs/lot-1'
  payload     TEXT NOT NULL,        -- JSON: {entries:[...], parent, base_root, remote_root}
  fetched_at  REAL NOT NULL
);
"""


class FsIndex:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._lock = threading.RLock()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as c:
            c.executescript(_SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.db_path, timeout=30, isolation_level=None)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        return c

    # ── reads ───────────────────────────────────────────────────────────
    def get(self, path: str) -> tuple[dict, float] | None:
        """Returns (payload, fetched_at_unix) or None when not yet indexed."""
        with self._lock, self._connect() as c:
            r = c.execute(
                "SELECT payload, fetched_at FROM fs_cache WHERE path=?",
                (path,),
            ).fetchone()
            if not r:
                return None
            return json.loads(r[0]), float(r[1])

    def all_paths(self) -> list[str]:
        with self._lock, self._connect() as c:
            rows = c.execute("SELECT path FROM fs_cache ORDER BY path").fetchall()
            return [r[0] for r in rows]

    # ── writes ──────────────────────────────────────────────────────────
    def put(self, path: str, payload: dict) -> None:
        now = time.time()
        with self._lock, self._connect() as c:
            c.execute(
                """INSERT INTO fs_cache (path, payload, fetched_at)
                   VALUES (?, ?, ?)
                   ON CONFLICT(path) DO UPDATE SET
                     payload    = excluded.payload,
                     fetched_at = excluded.fetched_at""",
                (path, json.dumps(payload), now),
            )

    def invalidate(self, path: str) -> None:
        with self._lock, self._connect() as c:
            c.execute("DELETE FROM fs_cache WHERE path=?", (path,))

    def invalidate_prefix(self, prefix: str) -> int:
        """Remove the given path, all its ancestors, and all descendants."""
        with self._lock, self._connect() as c:
            removed = 0
            cur: str | None = prefix
            while cur is not None:
                r = c.execute("DELETE FROM fs_cache WHERE path=?", (cur,))
                removed += r.rowcount or 0
                if cur == "":
                    break
                idx = cur.rfind("/")
                cur = cur[:idx] if idx > 0 else ""
            if prefix:
                r = c.execute("DELETE FROM fs_cache WHERE path LIKE ?", (prefix + "/%",))
                removed += r.rowcount or 0
            return removed

    def clear(self) -> None:
        with self._lock, self._connect() as c:
            c.execute("DELETE FROM fs_cache")

    def size(self) -> int:
        with self._lock, self._connect() as c:
            r = c.execute("SELECT COUNT(*) FROM fs_cache").fetchone()
            return int(r[0])
