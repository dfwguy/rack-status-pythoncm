"""Entry point: `python -m app`."""
from __future__ import annotations

import logging
import threading
import webbrowser

from app import create_app
from app.config import load_config

log = logging.getLogger(__name__)


def main() -> None:
    cfg = load_config()
    app, socketio = create_app(cfg)

    host = cfg.server.host
    port = cfg.server.port
    url = f"http://{host}:{port}/"

    if cfg.server.auto_open_browser:
        def _open():
            webbrowser.open(url)
        threading.Timer(0.8, _open).start()

    log.info("nvftp-sync listening at %s", url)
    socketio.run(app, host=host, port=port, allow_unsafe_werkzeug=True)


if __name__ == "__main__":
    main()
