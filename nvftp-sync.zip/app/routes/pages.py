"""Server-rendered pages."""
from __future__ import annotations

from flask import Blueprint, current_app, render_template

bp = Blueprint("pages", __name__)


@bp.route("/")
def index():
    cfg = current_app.config["NVFTP_CONFIG"]
    return render_template(
        "index.html",
        allowed_folders=cfg.allowed_folders,
        chunk_size=cfg.uploads.chunk_size,
        endpoints=cfg.endpoints,
    )


@bp.route("/settings")
def settings():
    cfg = current_app.config["NVFTP_CONFIG"]
    return render_template("settings.html", cfg=cfg)
