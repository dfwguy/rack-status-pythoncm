"""SocketIO event registrations. (Server pushes; client only listens.)"""
from __future__ import annotations

import logging

from flask_socketio import SocketIO

log = logging.getLogger(__name__)


def register(socketio: SocketIO) -> None:
    @socketio.on("connect")
    def _on_connect():
        log.debug("client connected")

    @socketio.on("disconnect")
    def _on_disconnect():
        log.debug("client disconnected")
