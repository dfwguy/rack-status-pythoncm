"""HTTP API.

Two surfaces share the same handlers:

  /api/chunk, /api/url-pull, /api/uploads/<id>/...
      — used by the browser. CSRF-free because the app binds to 127.0.0.1.

  /api/v1/...
      — versioned, bearer-token-protected API for external scripts.

Browser-only endpoints fall back to no-auth (loopback). Versioned API
requires `Authorization: Bearer <token>` unless `allow_loopback_no_auth`
is true and the request came from 127.0.0.1.
"""
from __future__ import annotations

import json
import logging
import time
from functools import wraps
from pathlib import Path
from typing import Any
from flask import Blueprint, Response, abort, current_app, jsonify, request, stream_with_context

from app import db
from app.sftp_pool import ConflictError, SftpError, connect, is_safe_subpath, join_path, list_dir_merged
from app.upload_manager import OffsetMismatch
from app.url_puller import derived_filename

log = logging.getLogger(__name__)
bp = Blueprint("api", __name__, url_prefix="/api")


# ── auth ─────────────────────────────────────────────────────────────────

def _client_is_loopback() -> bool:
    addr = request.remote_addr or ""
    return addr in ("127.0.0.1", "::1", "localhost")


def _require_token() -> None:
    cfg = current_app.config["NVFTP_CONFIG"]
    if cfg.server.allow_loopback_no_auth and _client_is_loopback():
        return
    token = cfg.server.api_token
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        abort(401, "Missing Authorization: Bearer <token> header")
    if auth[len("Bearer "):].strip() != token:
        abort(401, "Invalid API token")


def api_v1(f):
    @wraps(f)
    def wrapper(*a, **k):
        _require_token()
        return f(*a, **k)
    return wrapper


def _manager():
    return current_app.config["NVFTP_MANAGER"]


def _cfg():
    return current_app.config["NVFTP_CONFIG"]


# ── shared serializer ────────────────────────────────────────────────────

def _serialize(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": row["id"],
        "source": row["source"],
        "filename": row["filename"],
        "target_folder": row.get("subfolder") or row["target_folder"],
        "base_path": row["base_path"],
        "remote_path": row["remote_path"],
        "total_bytes": row["total_bytes"],
        "bytes_done": row["bytes_done"],
        "status": row["status"],
        "error_message": row.get("error_message"),
        "sha256_client": row.get("sha256_client"),
        "sha256_server": row.get("sha256_server"),
        "sha256_upstream": row.get("sha256_upstream"),
        "url": row.get("url"),
        "local_source": row.get("local_source"),
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"),
        "completed_at": row.get("completed_at"),
    }


# ════════════════════════════════════════════════════════════════════════
#   BROWSER-FACING ENDPOINTS  (no token required from loopback)
# ════════════════════════════════════════════════════════════════════════

def _conflict_response(e: ConflictError):
    return jsonify(
        error="conflict",
        message=str(e),
        existing=e.info,
        retry_with=["overwrite", "rename"],
    ), 409


@bp.post("/uploads")
def browser_create():
    """Create a browser upload, returning the upload_id to chunk against."""
    j = request.get_json(force=True, silent=True) or {}
    filename = (j.get("filename") or "").strip()
    target = (j.get("target_folder") or "").strip()
    total_bytes = int(j.get("total_bytes") or 0)
    sha_client = (j.get("sha256_expected") or None)
    on_conflict = (j.get("on_conflict") or None)
    if not filename or total_bytes <= 0:
        return jsonify(error="filename and total_bytes required"), 400
    try:
        h = _manager().create_browser_upload(
            filename=filename,
            target_folder=target,
            total_bytes=total_bytes,
            sha_client_expected=sha_client,
            on_conflict=on_conflict,
        )
    except ConflictError as e:
        return _conflict_response(e)
    except SftpError as e:
        return jsonify(error=str(e)), 400
    return jsonify(upload_id=h.upload_id, filename=h.filename, chunk_size=_cfg().uploads.chunk_size)


@bp.post("/chunk")
def browser_chunk():
    """Receive one binary chunk for a browser upload.

    Headers required: X-Upload-Id, X-Offset.
    Body: raw bytes.
    """
    upload_id = request.headers.get("X-Upload-Id", "")
    try:
        offset = int(request.headers.get("X-Offset", "0"))
    except ValueError:
        return jsonify(error="bad X-Offset"), 400
    data = request.get_data(cache=False)
    if not data:
        return jsonify(error="empty body"), 400
    try:
        new_offset = _manager().feed_chunk(upload_id, offset, data)
    except OffsetMismatch as e:
        return jsonify(error="offset_mismatch", server_offset=e.server_offset), 409
    except KeyError:
        return jsonify(error="unknown upload_id"), 404
    except SftpError as e:
        return jsonify(error=str(e)), 400
    return jsonify(server_offset=new_offset)


@bp.post("/uploads/<upload_id>/finalize")
def browser_finalize(upload_id: str):
    j = request.get_json(force=True, silent=True) or {}
    sha = (j.get("sha256") or "").strip().lower()
    try:
        _manager().finalize_browser(upload_id, sha)
    except KeyError:
        return jsonify(error="unknown upload_id"), 404
    return jsonify(ok=True)


@bp.post("/url-pull")
def browser_url_pull():
    j = request.get_json(force=True, silent=True) or {}
    return _create_url_pull(j)


def _create_url_pull(j: dict) -> Any:
    url = (j.get("url") or "").strip()
    if not url:
        return jsonify(error="url required"), 400
    target = (j.get("target_folder") or "").strip()
    filename = (j.get("filename") or "").strip() or derived_filename(url)
    verify_tls = bool(j.get("verify_tls", False))
    on_conflict = (j.get("on_conflict") or None)
    try:
        h = _manager().create_url_pull(
            url=url, filename=filename, target_folder=target, verify_tls=verify_tls,
            metadata=j.get("metadata") or {},
            on_conflict=on_conflict,
        )
    except ConflictError as e:
        return _conflict_response(e)
    except SftpError as e:
        return jsonify(error=str(e)), 400
    return jsonify(upload_id=h.upload_id, filename=h.filename)


# Shared pause/resume/stop (used by both browser and API v1).
def _action(upload_id: str, action: str):
    m = _manager()
    try:
        if action == "pause":
            m.pause(upload_id)
        elif action == "resume":
            m.resume(upload_id)
        elif action == "stop":
            m.stop(upload_id)
        else:
            return jsonify(error="unknown action"), 400
    except KeyError:
        return jsonify(error="unknown upload_id"), 404
    return jsonify(ok=True)


@bp.post("/uploads/<upload_id>/<action>")
def browser_action(upload_id: str, action: str):
    return _action(upload_id, action)


@bp.delete("/uploads/<upload_id>")
def browser_kill(upload_id: str):
    try:
        report = _manager().kill(upload_id)
    except KeyError:
        return jsonify(error="unknown upload_id"), 404
    return jsonify(ok=True, **report)


def _fetch_listing(cfg, path: str) -> dict:
    """Uncached fetch — called on cache miss or forced refresh."""
    if not path:
        ssh = connect(cfg)
        try:
            entries: list[dict] = []
            sftp_b = ssh.open_sftp()
            sftp_r = ssh.open_sftp()
            for top in cfg.allowed_folders:
                bp_ = join_path(cfg.endpoints.base, top)
                rp_ = join_path(cfg.endpoints.remote, top)
                def _st(s, p):
                    try:
                        a = s.stat(p)
                        return {"exists": True, "size": int(a.st_size or 0),
                                "mtime": int(a.st_mtime or 0)}
                    except FileNotFoundError:
                        return {"exists": False}
                be = _st(sftp_b, bp_)
                re_ = _st(sftp_r, rp_)
                if be["exists"] and re_["exists"]:
                    sync = "ok"
                elif be["exists"]:
                    sync = "base_only"
                elif re_["exists"]:
                    sync = "remote_only"
                else:
                    sync = "missing"
                entries.append({"name": top, "type": "dir",
                                "base": be, "remote": re_, "sync": sync})
            sftp_b.close(); sftp_r.close()
        finally:
            ssh.close()
        return {"path": "", "parent": None, "entries": entries,
                "base_root": cfg.endpoints.base, "remote_root": cfg.endpoints.remote}

    parent = "/".join(path.split("/")[:-1])
    ssh = connect(cfg)
    try:
        base_dir = join_path(cfg.endpoints.base, path)
        remote_dir = join_path(cfg.endpoints.remote, path)
        entries = list_dir_merged(ssh, base_dir, remote_dir)
    finally:
        ssh.close()
    return {"path": path, "parent": parent, "entries": entries,
            "base_root": cfg.endpoints.base, "remote_root": cfg.endpoints.remote}


def _files_listing(path: str, *, refresh: bool = False) -> dict:
    """Merged directory listing, served from the persistent FsIndex.

    Response includes `synced_at` (unix seconds when the index was last
    refreshed for this path) and `age_seconds` so the UI can show
    'synced Xs ago'. The background FsSyncer keeps the index warm; the
    user only pays the live-SSH cost on the very first visit to a deep
    folder or when they hit ?refresh=1.
    """
    cfg = _cfg()
    index = current_app.config["NVFTP_FS_INDEX"]
    path = (path or "").strip().strip("/")
    if path and not is_safe_subpath(path, cfg.allowed_folders):
        return {"error": f"path must start with one of {cfg.allowed_folders} (no traversal)"}

    if refresh:
        # Force a live fetch, then update the index.
        value = _fetch_listing(cfg, path)
        index.put(path, value)
        return {**value, "synced_at": time.time(), "age_seconds": 0.0,
                "from_index": False}

    hit = index.get(path)
    if hit is not None:
        value, fetched_at = hit
        return {**value, "synced_at": fetched_at,
                "age_seconds": round(time.time() - fetched_at, 1),
                "from_index": True}

    # Cold path: never seen this folder before — fetch live now.
    value = _fetch_listing(cfg, path)
    index.put(path, value)
    return {**value, "synced_at": time.time(), "age_seconds": 0.0,
            "from_index": False}


@bp.get("/files")
def browser_files():
    refresh = request.args.get("refresh") in ("1", "true", "yes")
    res = _files_listing(request.args.get("path", ""), refresh=refresh)
    if "error" in res:
        return jsonify(res), 400
    return jsonify(res)


@bp.get("/uploads")
def browser_list():
    rows = db.list_uploads(limit=int(request.args.get("limit", 200)))
    return jsonify([_serialize(r) for r in rows])


@bp.get("/uploads/<upload_id>")
def browser_get(upload_id: str):
    row = db.get_upload(upload_id)
    if not row:
        return jsonify(error="not found"), 404
    return jsonify(_serialize(row))


# ════════════════════════════════════════════════════════════════════════
#   /api/v1/*  — scriptable, bearer-token protected
# ════════════════════════════════════════════════════════════════════════

@bp.get("/v1/health")
@api_v1
def v1_health():
    return jsonify(ok=True, version=1)


@bp.get("/v1/config")
@api_v1
def v1_config():
    cfg = _cfg()
    return jsonify(
        endpoints={"base": cfg.endpoints.base, "remote": cfg.endpoints.remote},
        allowed_folders=cfg.allowed_folders,
        chunk_size=cfg.uploads.chunk_size,
        max_concurrent=cfg.uploads.max_concurrent,
    )


@bp.post("/v1/uploads")
@api_v1
def v1_create():
    """Submit a job by source = 'url' or 'local_path'.

    JSON body:
      {
        "source": "url" | "local_path",
        "url": "...",                # when source=url
        "local_path": "/abs/path",   # when source=local_path; readable by the server process
        "target_folder": "btrfs",    # one of allowed_folders (sub-paths allowed)
        "filename": "optional override",
        "verify_tls": true,          # url only
        "metadata": { ... }
      }
    """
    j = request.get_json(force=True, silent=True) or {}
    source = (j.get("source") or "").strip()
    target = (j.get("target_folder") or "").strip()
    if not is_safe_subpath(target, _cfg().allowed_folders):
        return jsonify(error=f"target_folder must start with one of {_cfg().allowed_folders} and contain no '..'"), 400
    try:
        if source == "url":
            return _create_url_pull(j)
        if source == "local_path":
            local_path = (j.get("local_path") or "").strip()
            if not local_path:
                return jsonify(error="local_path required"), 400
            p = Path(local_path).expanduser()
            if not p.is_file():
                return jsonify(error=f"file not readable: {p}"), 400
            h = _manager().create_local_file(
                local_source=str(p),
                filename=(j.get("filename") or "").strip() or p.name,
                target_folder=target,
                metadata=j.get("metadata") or {},
                on_conflict=(j.get("on_conflict") or None),
            )
            return jsonify(upload_id=h.upload_id, filename=h.filename,
                           status_url=f"/api/v1/uploads/{h.upload_id}")
        return jsonify(error="source must be 'url' or 'local_path' (use POST /api/v1/uploads/file for multipart)"), 400
    except ConflictError as e:
        return _conflict_response(e)
    except SftpError as e:
        return jsonify(error=str(e)), 400


@bp.post("/v1/uploads/file")
@api_v1
def v1_create_multipart():
    """Streaming multipart upload from a script.

    Form fields:
      file:           binary file part (required)
      target_folder:  e.g. 'btrfs' (required)
      filename:       optional override
      metadata:       optional JSON string
    """
    target = (request.form.get("target_folder") or "").strip()
    fs = request.files.get("file")
    if not fs:
        return jsonify(error="file field required"), 400
    filename = (request.form.get("filename") or fs.filename or "upload.bin").strip()
    metadata_raw = request.form.get("metadata")
    metadata = {}
    if metadata_raw:
        try:
            metadata = json.loads(metadata_raw)
        except json.JSONDecodeError:
            return jsonify(error="metadata must be JSON"), 400
    # Stage to a temp file (so we get a known total_bytes) then submit as a local job.
    from tempfile import NamedTemporaryFile
    tmp = NamedTemporaryFile(prefix="nvftp-", delete=False)
    try:
        while True:
            buf = fs.stream.read(8 * 1024 * 1024)
            if not buf:
                break
            tmp.write(buf)
        tmp.flush()
        tmp.close()
        h = _manager().create_local_file(
            local_source=tmp.name,
            filename=Path(filename).name,
            target_folder=target,
            metadata={**metadata, "multipart_staged": True, "tmp_path": tmp.name},
            on_conflict=(request.form.get("on_conflict") or None),
        )
        return jsonify(upload_id=h.upload_id, filename=h.filename,
                       status_url=f"/api/v1/uploads/{h.upload_id}")
    except ConflictError as e:
        return _conflict_response(e)
    except SftpError as e:
        return jsonify(error=str(e)), 400


@bp.get("/v1/uploads")
@api_v1
def v1_list():
    status = request.args.get("status")
    rows = db.list_uploads(status=status, limit=int(request.args.get("limit", 200)))
    return jsonify([_serialize(r) for r in rows])


@bp.get("/v1/uploads/<upload_id>")
@api_v1
def v1_get(upload_id: str):
    row = db.get_upload(upload_id)
    if not row:
        return jsonify(error="not found"), 404
    return jsonify(_serialize(row))


@bp.post("/v1/uploads/<upload_id>/<action>")
@api_v1
def v1_action(upload_id: str, action: str):
    return _action(upload_id, action)


@bp.delete("/v1/uploads/<upload_id>")
@api_v1
def v1_kill(upload_id: str):
    try:
        report = _manager().kill(upload_id)
    except KeyError:
        return jsonify(error="not found"), 404
    return jsonify(ok=True, **report)


@bp.get("/v1/files")
@api_v1
def v1_files():
    refresh = request.args.get("refresh") in ("1", "true", "yes")
    res = _files_listing(request.args.get("path", ""), refresh=refresh)
    if "error" in res:
        return jsonify(res), 400
    return jsonify(res)


@bp.get("/v1/uploads/<upload_id>/events")
@api_v1
def v1_sse(upload_id: str):
    """Server-Sent Events stream for a single upload. Closes when terminal."""
    import time

    def _gen():
        last = None
        while True:
            row = db.get_upload(upload_id)
            if not row:
                yield "event: error\ndata: not found\n\n"
                return
            payload = json.dumps(_serialize(row))
            if payload != last:
                yield f"data: {payload}\n\n"
                last = payload
            if row["status"] in ("complete", "failed", "corrupt"):
                return
            time.sleep(0.5)

    return Response(stream_with_context(_gen()), mimetype="text/event-stream")


@bp.post("/v1/test-connection")
@api_v1
def v1_test_connection():
    cfg = _cfg()
    try:
        ssh = connect(cfg)
        sftp = ssh.open_sftp()
        for p in (cfg.endpoints.base, cfg.endpoints.remote):
            sftp.stat(p)
        sftp.close()
        ssh.close()
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 502


@bp.get("/v1/audit.csv")
@api_v1
def v1_audit_csv():
    return Response(stream_with_context(db.export_audit_csv()), mimetype="text/csv")
