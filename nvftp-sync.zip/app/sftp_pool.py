"""Paramiko SSH/SFTP helpers and the DualWriter that mirrors writes to two paths."""
from __future__ import annotations

import logging
import os
import threading
from contextlib import contextmanager
from pathlib import PurePosixPath
from typing import Iterator

import paramiko

from app.config import Config, expand_path

log = logging.getLogger(__name__)


class SftpError(RuntimeError):
    pass


class ConflictError(SftpError):
    """Raised when the target filename already exists and policy is 'error'.

    `info` is the dict returned by stat_existing(): per-endpoint exists/size.
    """
    def __init__(self, message: str, info: dict) -> None:
        super().__init__(message)
        self.info = info


def stat_existing(ssh: paramiko.SSHClient, base_path: str, remote_path: str) -> dict:
    """Quick-stat both target paths. Returns:
       {'base': {'exists': bool, 'size': int|None}, 'remote': {...}}.
    """
    sftp = ssh.open_sftp()
    try:
        def _one(p: str) -> dict:
            try:
                a = sftp.stat(p)
                return {"exists": True, "size": int(a.st_size or 0)}
            except FileNotFoundError:
                return {"exists": False, "size": None}
        return {"base": _one(base_path), "remote": _one(remote_path)}
    finally:
        sftp.close()


def remove_if_exists(ssh: paramiko.SSHClient, paths: list[str]) -> list[str]:
    """Delete each path that exists. Returns the list of paths actually removed."""
    sftp = ssh.open_sftp()
    removed: list[str] = []
    try:
        for p in paths:
            try:
                sftp.remove(p)
                removed.append(p)
            except FileNotFoundError:
                pass
        return removed
    finally:
        sftp.close()


def _load_pkey(key_path: str, passphrase: str | None) -> paramiko.PKey:
    p = expand_path(key_path)
    if not p.exists():
        raise SftpError(f"SSH key not found: {p}")
    candidates: list = []
    for name in ("Ed25519Key", "ECDSAKey", "RSAKey", "DSSKey"):
        cls = getattr(paramiko, name, None)
        if cls is not None:
            candidates.append(cls)
    last_exc: Exception | None = None
    for cls in candidates:
        try:
            return cls.from_private_key_file(str(p), password=passphrase)
        except paramiko.ssh_exception.PasswordRequiredException:
            raise SftpError(f"Key {p} is encrypted; set sftp.key_passphrase in config.yaml")
        except paramiko.SSHException as e:
            last_exc = e
    raise SftpError(f"Could not parse SSH key {p}: {last_exc}")


def connect(cfg: Config) -> paramiko.SSHClient:
    ssh = paramiko.SSHClient()
    if cfg.sftp.strict_host_key_checking:
        try:
            ssh.load_host_keys(str(expand_path(cfg.sftp.known_hosts)))
        except FileNotFoundError:
            pass
        ssh.set_missing_host_key_policy(paramiko.RejectPolicy())
    else:
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    pkey = _load_pkey(cfg.sftp.key_path, cfg.sftp.key_passphrase)
    log.info("Connecting to %s@%s:%s", cfg.sftp.username, cfg.sftp.host, cfg.sftp.port)
    ssh.connect(
        hostname=cfg.sftp.host,
        port=cfg.sftp.port,
        username=cfg.sftp.username,
        pkey=pkey,
        look_for_keys=False,
        allow_agent=False,
        timeout=30,
    )
    transport = ssh.get_transport()
    if transport is not None:
        transport.set_keepalive(30)
    return ssh


@contextmanager
def open_ssh(cfg: Config) -> Iterator[paramiko.SSHClient]:
    ssh = connect(cfg)
    try:
        yield ssh
    finally:
        try:
            ssh.close()
        except Exception:
            pass


def _ensure_dir(sftp: paramiko.SFTPClient, posix_path: str) -> None:
    """mkdir -p equivalent."""
    parts = PurePosixPath(posix_path).parts
    cur = ""
    for part in parts:
        if part == "/":
            cur = "/"
            continue
        cur = cur.rstrip("/") + "/" + part if cur else part
        try:
            sftp.stat(cur)
        except FileNotFoundError:
            try:
                sftp.mkdir(cur)
            except IOError as e:
                # Race or permission — recheck.
                try:
                    sftp.stat(cur)
                except Exception:
                    raise SftpError(f"Cannot create {cur}: {e}")


def stat_size(sftp: paramiko.SFTPClient, path: str) -> int:
    try:
        return sftp.stat(path).st_size or 0
    except FileNotFoundError:
        return 0


def truncate(sftp: paramiko.SFTPClient, path: str, size: int) -> None:
    """Truncate file to `size`. paramiko's SFTPClient.truncate accepts this."""
    sftp.truncate(path, size)


def statvfs_free_bytes(sftp: paramiko.SFTPClient, path: str) -> int | None:
    """Returns free bytes on the volume containing `path`, or None if unsupported."""
    try:
        s = sftp.statvfs(path)
    except (IOError, OSError, AttributeError):
        return None
    return int(s.f_bavail) * int(s.f_frsize)


class DualWriter:
    """Writes every chunk to two SFTP paths on the same SSH connection.

    Uses two distinct SFTP channels so writes can pipeline independently.
    """

    def __init__(self, ssh: paramiko.SSHClient, base_path: str, remote_path: str) -> None:
        self._ssh = ssh
        self.base_path = base_path
        self.remote_path = remote_path
        self._sftp_b = ssh.open_sftp()
        self._sftp_r = ssh.open_sftp()
        _ensure_dir(self._sftp_b, str(PurePosixPath(base_path).parent))
        _ensure_dir(self._sftp_r, str(PurePosixPath(remote_path).parent))
        self._fb = self._sftp_b.open(base_path, "ab")
        self._fr = self._sftp_r.open(remote_path, "ab")
        self._fb.set_pipelined(True)
        self._fr.set_pipelined(True)
        self._lock = threading.Lock()
        self._closed = False

    def write(self, chunk: bytes) -> None:
        if not chunk:
            return
        with self._lock:
            if self._closed:
                raise SftpError("DualWriter is closed")
            self._fb.write(chunk)
            self._fr.write(chunk)

    def flush(self) -> None:
        with self._lock:
            try:
                self._fb.flush()
            except Exception:
                pass
            try:
                self._fr.flush()
            except Exception:
                pass

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
        errs: list[Exception] = []
        for f in (self._fb, self._fr):
            try:
                f.close()
            except Exception as e:
                errs.append(e)
        for s in (self._sftp_b, self._sftp_r):
            try:
                s.close()
            except Exception:
                pass
        if errs:
            log.warning("Errors while closing DualWriter: %s", errs)

    def __enter__(self) -> "DualWriter":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def prepare_for_upload(
    ssh: paramiko.SSHClient,
    base_path: str,
    remote_path: str,
    *,
    fresh: bool,
) -> int:
    """Reconciles the two endpoints before writing.

    If `fresh`, removes any existing partial on both sides and returns 0.
    Otherwise computes `min(size_base, size_remote)`, truncates the larger
    side down to that offset, and returns the resume offset.
    """
    sftp = ssh.open_sftp()
    try:
        _ensure_dir(sftp, str(PurePosixPath(base_path).parent))
        _ensure_dir(sftp, str(PurePosixPath(remote_path).parent))
        if fresh:
            for p in (base_path, remote_path):
                try:
                    sftp.remove(p)
                except FileNotFoundError:
                    pass
            return 0
        sb = stat_size(sftp, base_path)
        sr = stat_size(sftp, remote_path)
        offset = min(sb, sr)
        if sb > offset:
            truncate(sftp, base_path, offset)
        if sr > offset:
            truncate(sftp, remote_path, offset)
        return offset
    finally:
        sftp.close()


def preflight_free_space(ssh: paramiko.SSHClient, paths: list[str], need_bytes: int) -> str | None:
    """Returns a human warning string if any endpoint lacks space, else None."""
    sftp = ssh.open_sftp()
    try:
        for p in paths:
            parent = str(PurePosixPath(p).parent)
            free = statvfs_free_bytes(sftp, parent)
            if free is None:
                continue
            if free < need_bytes * 2:  # both writes consume separately
                return f"{parent}: only {free / 1e9:.1f} GB free, need ~{need_bytes / 1e9:.1f} GB"
        return None
    finally:
        sftp.close()


def join_path(*parts: str) -> str:
    """POSIX path join that keeps the leading slash."""
    out = "/"
    for p in parts:
        if not p:
            continue
        if p.startswith("/"):
            out = p
        else:
            out = out.rstrip("/") + "/" + p.lstrip("/")
    return out


def list_dir_merged(
    ssh: paramiko.SSHClient, base_dir: str, remote_dir: str
) -> list[dict]:
    """List a directory on both endpoints and return one merged view.

    Each entry: {name, type, base: {exists,size,mtime}, remote: {...}, sync}.
    sync ∈ {ok, base_only, remote_only, size_mismatch, type_mismatch}.
    """
    sftp = ssh.open_sftp()
    try:
        def _attrs(path: str) -> dict[str, dict]:
            try:
                items = sftp.listdir_attr(path)
            except FileNotFoundError:
                return {}
            out: dict[str, dict] = {}
            for a in items:
                is_dir = bool(a.st_mode and (a.st_mode & 0o170000) == 0o040000)
                out[a.filename] = {
                    "exists": True,
                    "size": int(a.st_size or 0),
                    "mtime": int(a.st_mtime or 0),
                    "is_dir": is_dir,
                }
            return out

        b = _attrs(base_dir)
        r = _attrs(remote_dir)
    finally:
        sftp.close()

    names = sorted(set(b) | set(r), key=lambda n: (not (b.get(n) or r.get(n) or {}).get("is_dir"), n.lower()))
    entries: list[dict] = []
    for name in names:
        be = b.get(name)
        re_ = r.get(name)
        if be and re_:
            if be["is_dir"] != re_["is_dir"]:
                sync = "type_mismatch"
            elif not be["is_dir"] and be["size"] != re_["size"]:
                sync = "size_mismatch"
            else:
                sync = "ok"
        elif be and not re_:
            sync = "base_only"
        else:
            sync = "remote_only"
        ref = be or re_ or {}
        entries.append({
            "name": name,
            "type": "dir" if ref.get("is_dir") else "file",
            "base":   {"exists": bool(be), "size": (be or {}).get("size"),  "mtime": (be or {}).get("mtime")},
            "remote": {"exists": bool(re_), "size": (re_ or {}).get("size"), "mtime": (re_ or {}).get("mtime")},
            "sync": sync,
        })
    return entries


def is_safe_subpath(folder: str, allowed_top: list[str]) -> bool:
    """Reject absolute paths and ../ traversal. Top-level must be in allowed_top."""
    if not folder:
        return False
    if folder.startswith("/") or folder.startswith("\\"):
        return False
    raw_parts = folder.replace("\\", "/").split("/")
    if any(p == ".." for p in raw_parts):
        return False
    norm = os.path.normpath(folder).replace("\\", "/")
    if norm.startswith("/") or ".." in norm.split("/"):
        return False
    top = norm.split("/", 1)[0]
    return top in allowed_top
