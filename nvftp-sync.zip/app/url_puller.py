"""Stream an HTTP URL straight into a DualWriter, with Range-resume support."""
from __future__ import annotations

import binascii
import http.client
import logging
import time
from typing import Callable, Optional
from urllib.parse import urlparse

import requests
import urllib3

from app.hashing import IncrementalSha256
from app.sftp_pool import DualWriter, SftpError

# TLS verification is off by default for URL pulls. Suppress urllib3's
# per-request InsecureRequestWarning so logs stay readable.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

log = logging.getLogger(__name__)

# Maximum bytes to discard if upstream ignored Range and replied 200.
_MAX_DISCARD_ON_NO_RANGE = 200 * 1024 * 1024  # 200 MiB safety cap

# Network errors that mean "the connection died but the bytes we already
# wrote are still valid" — safe to reconnect with Range from where we left off.
_RETRYABLE: tuple[type[BaseException], ...] = (
    requests.exceptions.ChunkedEncodingError,
    requests.exceptions.ConnectionError,
    requests.exceptions.Timeout,
    requests.exceptions.ContentDecodingError,
    urllib3.exceptions.ProtocolError,
    urllib3.exceptions.IncompleteRead,
    http.client.IncompleteRead,
    ConnectionResetError,
)

OnChunk = Callable[[int, Optional[int], Optional[str]], bool]


def derived_filename(url: str) -> str:
    name = urlparse(url).path.rsplit("/", 1)[-1]
    return name or "download.bin"


def _upstream_sha256(headers: dict[str, str]) -> str | None:
    """Best-effort extraction of an upstream-declared SHA-256."""
    for k in ("X-Checksum-Sha256", "X-Content-SHA256", "X-Amz-Meta-Sha256", "X-Goog-Hash"):
        v = headers.get(k)
        if not v:
            continue
        if k == "X-Goog-Hash":
            # Format: 'sha256=BASE64,md5=BASE64'
            for part in v.split(","):
                kv = part.strip().split("=", 1)
                if len(kv) == 2 and kv[0].strip().lower() == "sha256":
                    try:
                        return binascii.hexlify(binascii.a2b_base64(kv[1].strip())).decode()
                    except Exception:
                        pass
            continue
        v = v.strip()
        if len(v) == 64 and all(c in "0123456789abcdefABCDEF" for c in v):
            return v.lower()
    return None


def pull(
    *,
    url: str,
    writer: DualWriter,
    start_offset: int = 0,
    verify_tls: bool = True,
    connect_timeout: int = 10,
    read_timeout: int = 60,
    chunk_size: int = 4 * 1024 * 1024,
    headers: dict[str, str] | None = None,
    on_chunk: OnChunk | None = None,
    sha_state: IncrementalSha256 | None = None,
    max_retries: int = 6,
) -> dict:
    """Pull `url` into `writer`, starting at byte `start_offset`.

    Retries transparently on transient HTTP errors (connection reset,
    IncompleteRead, chunked-encoding glitches) by re-issuing a GET with
    `Range: bytes=<bytes_so_far>-`. The SHA-256 keeps accumulating across
    retries because nothing already written is re-read.

    on_chunk receives (bytes_written_this_call, total_content_length_or_None, upstream_sha_or_None)
    and returns True to continue, False to abort cleanly.

    Returns: {'bytes': int, 'upstream_sha': str|None, 'http_status': int}
    """
    sha_state = sha_state or IncrementalSha256()
    log.info("URL pull: %s (offset=%d, verify_tls=%s)", url, start_offset, verify_tls)
    bytes_written = 0
    upstream_sha: str | None = None
    total: int | None = None
    last_status = 0
    attempt = 0
    backoff = 1.0

    while True:
        cur_offset = start_offset + bytes_written
        req_headers: dict[str, str] = dict(headers or {})
        if cur_offset > 0:
            req_headers["Range"] = f"bytes={cur_offset}-"

        try:
            with requests.get(
                url,
                stream=True,
                headers=req_headers,
                verify=verify_tls,
                timeout=(connect_timeout, read_timeout),
                allow_redirects=True,
            ) as r:
                r.raise_for_status()
                last_status = r.status_code
                if upstream_sha is None:
                    upstream_sha = _upstream_sha256(r.headers)
                cl = r.headers.get("Content-Length")
                if cl and total is None:
                    total = int(cl) + (cur_offset if r.status_code == 206 else 0)

                # Handle the case where the server ignored Range.
                skip_remaining = 0
                if cur_offset > 0 and r.status_code == 200:
                    if cur_offset > _MAX_DISCARD_ON_NO_RANGE:
                        raise SftpError(
                            f"Upstream ignored Range and {cur_offset} bytes exceeds discard cap; "
                            "delete the partial and restart this upload."
                        )
                    log.warning(
                        "Upstream ignored Range; will discard first %d bytes from stream", cur_offset
                    )
                    skip_remaining = cur_offset

                for chunk in r.iter_content(chunk_size=chunk_size):
                    if not chunk:
                        continue
                    if skip_remaining > 0:
                        if len(chunk) <= skip_remaining:
                            skip_remaining -= len(chunk)
                            continue
                        chunk = chunk[skip_remaining:]
                        skip_remaining = 0
                    writer.write(chunk)
                    sha_state.update(chunk)
                    bytes_written += len(chunk)
                    cont = True
                    if on_chunk:
                        cont = on_chunk(len(chunk), total, upstream_sha)
                    if not cont:
                        log.info("URL pull aborted by callback at %d bytes", bytes_written)
                        return {"bytes": bytes_written, "upstream_sha": upstream_sha, "http_status": last_status}

                # Stream ended cleanly.
                # If we know the total size and haven't reached it, the upstream
                # closed early — treat as retryable.
                if total is not None and start_offset + bytes_written < total:
                    raise requests.exceptions.ChunkedEncodingError(
                        f"upstream closed at {start_offset + bytes_written}/{total} bytes"
                    )
                return {"bytes": bytes_written, "upstream_sha": upstream_sha, "http_status": last_status}

        except _RETRYABLE as e:
            attempt += 1
            if attempt > max_retries:
                log.error(
                    "URL pull exhausted %d retries at offset %d: %r",
                    max_retries, start_offset + bytes_written, e,
                )
                raise
            log.warning(
                "URL pull transient error (attempt %d/%d) at offset %d: %s; retrying in %.1fs",
                attempt, max_retries, start_offset + bytes_written,
                type(e).__name__, backoff,
            )
            time.sleep(backoff)
            backoff = min(backoff * 2, 30.0)
