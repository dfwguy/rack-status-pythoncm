"""SQLite persistence for uploads and audit log."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Iterable

from app.config import DATA_DIR

DB_PATH = DATA_DIR / "uploads.sqlite"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS uploads (
  id              TEXT PRIMARY KEY,
  source          TEXT NOT NULL,           -- 'browser' | 'url' | 'local'
  filename        TEXT NOT NULL,
  target_folder   TEXT NOT NULL,
  subfolder       TEXT NOT NULL DEFAULT '',
  base_path       TEXT NOT NULL,
  remote_path     TEXT NOT NULL,
  total_bytes     INTEGER,                 -- nullable when unknown (chunked stream)
  bytes_done      INTEGER NOT NULL DEFAULT 0,
  sha256_client   TEXT,
  sha256_server   TEXT,
  sha256_upstream TEXT,                    -- from upstream HTTP headers when available
  status          TEXT NOT NULL,           -- queued | uploading | paused | complete | failed | corrupt
  error_message   TEXT,
  url             TEXT,
  local_source    TEXT,                    -- path on disk for source='local'
  verify_tls      INTEGER NOT NULL DEFAULT 1,
  created_at      REAL NOT NULL,
  updated_at      REAL NOT NULL,
  completed_at    REAL,
  metadata_json   TEXT                     -- arbitrary client-supplied tags
);

CREATE INDEX IF NOT EXISTS idx_uploads_status ON uploads(status);
CREATE INDEX IF NOT EXISTS idx_uploads_created ON uploads(created_at);

CREATE TABLE IF NOT EXISTS audit (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  upload_id   TEXT,
  event       TEXT NOT NULL,
  detail      TEXT,
  at          REAL NOT NULL
);
"""

_lock = threading.Lock()


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=NORMAL")
    return c


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with _lock, _conn() as c:
        c.executescript(_SCHEMA)


def now() -> float:
    return time.time()


def insert_upload(row: dict[str, Any]) -> None:
    row.setdefault("created_at", now())
    row["updated_at"] = now()
    if isinstance(row.get("metadata"), dict):
        row["metadata_json"] = json.dumps(row.pop("metadata"))
    cols = ",".join(row.keys())
    placeholders = ",".join("?" for _ in row)
    with _lock, _conn() as c:
        c.execute(f"INSERT INTO uploads ({cols}) VALUES ({placeholders})", tuple(row.values()))


def update_upload(upload_id: str, **fields: Any) -> None:
    if not fields:
        return
    fields["updated_at"] = now()
    sets = ",".join(f"{k}=?" for k in fields)
    with _lock, _conn() as c:
        c.execute(f"UPDATE uploads SET {sets} WHERE id=?", (*fields.values(), upload_id))


def get_upload(upload_id: str) -> dict[str, Any] | None:
    with _lock, _conn() as c:
        r = c.execute("SELECT * FROM uploads WHERE id=?", (upload_id,)).fetchone()
        return dict(r) if r else None


def list_uploads(status: str | None = None, limit: int = 200) -> list[dict[str, Any]]:
    with _lock, _conn() as c:
        if status:
            rows = c.execute(
                "SELECT * FROM uploads WHERE status=? ORDER BY created_at DESC LIMIT ?",
                (status, limit),
            ).fetchall()
        else:
            rows = c.execute(
                "SELECT * FROM uploads ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]


def list_active() -> list[dict[str, Any]]:
    with _lock, _conn() as c:
        rows = c.execute(
            "SELECT * FROM uploads WHERE status IN ('queued','uploading','paused') ORDER BY created_at ASC"
        ).fetchall()
        return [dict(r) for r in rows]


def audit(upload_id: str | None, event: str, detail: str | dict | None = None) -> None:
    if isinstance(detail, dict):
        detail = json.dumps(detail)
    with _lock, _conn() as c:
        c.execute(
            "INSERT INTO audit (upload_id, event, detail, at) VALUES (?,?,?,?)",
            (upload_id, event, detail, now()),
        )


def export_audit_csv() -> Iterable[str]:
    yield "at,upload_id,event,detail\n"
    with _lock, _conn() as c:
        for r in c.execute("SELECT at, upload_id, event, detail FROM audit ORDER BY at ASC"):
            detail = (r["detail"] or "").replace('"', '""')
            yield f'{r["at"]:.3f},{r["upload_id"] or ""},{r["event"]},"{detail}"\n'


def delete_upload(upload_id: str) -> None:
    with _lock, _conn() as c:
        c.execute("DELETE FROM uploads WHERE id=?", (upload_id,))


def recover_crashed_on_startup() -> int:
    """Any row left in 'uploading' from a previous crash is moved to 'paused'."""
    with _lock, _conn() as c:
        cur = c.execute(
            "UPDATE uploads SET status='paused', updated_at=? WHERE status='uploading'",
            (now(),),
        )
        n = cur.rowcount or 0
    if n:
        audit(None, "crash_recovery", f"moved {n} upload(s) from uploading→paused on startup")
    return n
