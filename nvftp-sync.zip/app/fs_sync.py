"""Event-driven SFTP-to-FsIndex refresher.

NOT a periodic poller. The worker thread blocks on a queue and only
wakes up when something explicitly asks for a refresh:

- Once on startup: enqueue root + the four top-level folders so the
  first browse is instant.
- Each time an upload reaches a terminal state: the manager calls
  request_refresh(target_folder), which fans out to that folder and all
  ancestors back to root.
- When the user clicks Refresh in the UI, the /api/files?refresh=1 path
  bypasses the index entirely and fetches live — no need to touch the
  syncer for that.

Keeping the work off the request thread means the UI never waits on a
slow SFTP listdir; the refresh happens in the background and the next
user navigation reads the updated rows from SQLite.
"""
from __future__ import annotations

import logging
import queue
import threading
from typing import Callable

from app.config import Config
from app.fs_index import FsIndex

log = logging.getLogger(__name__)


class FsSyncer:
    def __init__(
        self,
        cfg: Config,
        fs_index: FsIndex,
        fetch_listing: Callable[[Config, str], dict],
    ) -> None:
        self.cfg = cfg
        self.index = fs_index
        self.fetch_listing = fetch_listing
        self._queue: "queue.Queue[str | None]" = queue.Queue()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        # Seed: root + top-levels, so first browse is fast.
        for p in [""] + list(self.cfg.allowed_folders):
            self._queue.put(p)
        self._thread = threading.Thread(target=self._loop, name="fs-syncer", daemon=True)
        self._thread.start()
        log.info("FsSyncer started (event-driven, no periodic polling)")

    def stop(self) -> None:
        self._stop.set()
        self._queue.put(None)   # unblock the worker

    def request_refresh(self, path: str) -> None:
        """Schedule `path` (and ancestors back to root) for refresh ASAP."""
        cur: str | None = path or ""
        while cur is not None:
            self._queue.put(cur)
            if cur == "":
                break
            idx = cur.rfind("/")
            cur = cur[:idx] if idx > 0 else ""

    # ── internals ───────────────────────────────────────────────────────
    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                path = self._queue.get(timeout=60)
            except queue.Empty:
                continue
            if path is None or self._stop.is_set():
                return
            try:
                self._sync_path(path)
            except Exception:
                log.exception("FsSyncer error syncing %s", path or "<root>")

    def _sync_path(self, path: str) -> None:
        try:
            payload = self.fetch_listing(self.cfg, path)
            self.index.put(path, payload)
            log.debug("synced %s (%d entries)", path or "<root>",
                      len(payload.get("entries", [])))
        except Exception as e:
            log.warning("fs sync failed for %s: %s", path or "<root>", e)
