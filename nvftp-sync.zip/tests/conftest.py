"""Shared pytest fixtures. Redirects DB/log/data paths to a tmp dir so tests are isolated."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


@pytest.fixture(autouse=True)
def _isolated_data(tmp_path, monkeypatch):
    import app.config as cfgmod
    import app.db as dbmod
    monkeypatch.setattr(cfgmod, "DATA_DIR", tmp_path / "data", raising=False)
    monkeypatch.setattr(cfgmod, "API_TOKEN_FILE", tmp_path / "data" / ".api_token", raising=False)
    monkeypatch.setattr(dbmod, "DB_PATH", tmp_path / "data" / "uploads.sqlite", raising=False)
    (tmp_path / "data").mkdir(parents=True, exist_ok=True)
    (tmp_path / "logs").mkdir(parents=True, exist_ok=True)
    yield
