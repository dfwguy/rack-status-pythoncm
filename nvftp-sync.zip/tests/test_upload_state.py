"""State machine sanity: DB initialization, crash recovery, list filters."""
from __future__ import annotations

from app import db


def _row(**over):
    base = {
        "id": "abc",
        "source": "url",
        "filename": "x.bin",
        "target_folder": "btrfs",
        "subfolder": "btrfs",
        "base_path": "/base/btrfs/x.bin",
        "remote_path": "/remote/btrfs/x.bin",
        "total_bytes": 1000,
        "bytes_done": 0,
        "status": "queued",
        "url": "https://example/x",
        "verify_tls": 1,
    }
    base.update(over)
    return base


def test_init_and_insert_get():
    db.init_db()
    db.insert_upload(_row())
    r = db.get_upload("abc")
    assert r["filename"] == "x.bin"
    assert r["status"] == "queued"


def test_crash_recovery_moves_uploading_to_paused():
    db.init_db()
    db.insert_upload(_row(id="u1", status="uploading"))
    db.insert_upload(_row(id="u2", status="queued"))
    db.insert_upload(_row(id="u3", status="complete"))
    n = db.recover_crashed_on_startup()
    assert n == 1
    assert db.get_upload("u1")["status"] == "paused"
    assert db.get_upload("u2")["status"] == "queued"
    assert db.get_upload("u3")["status"] == "complete"


def test_list_filters():
    db.init_db()
    db.insert_upload(_row(id="a", status="queued"))
    db.insert_upload(_row(id="b", status="complete"))
    db.insert_upload(_row(id="c", status="failed"))
    queued = db.list_uploads(status="queued")
    assert {r["id"] for r in queued} == {"a"}
    all_rows = db.list_uploads()
    assert {r["id"] for r in all_rows} == {"a", "b", "c"}


def test_delete_upload_removes_row():
    db.init_db()
    db.insert_upload(_row(id="kme", status="paused", bytes_done=100))
    assert db.get_upload("kme") is not None
    db.delete_upload("kme")
    assert db.get_upload("kme") is None
