"""Resume offset reconciliation."""
from __future__ import annotations

from unittest.mock import MagicMock

from app import sftp_pool


def _ssh_with_sizes(size_base: int, size_remote: int):
    """Build an SSHClient that returns the given sizes for stat() on the two files."""
    truncations: list[tuple[str, int]] = []

    class S:
        def __init__(self) -> None:
            self.dirs = {"/", "/base", "/base/dir", "/remote", "/remote/dir"}

        def stat(self, p):
            if p in self.dirs:
                return MagicMock(st_size=0)
            m = MagicMock()
            if p.startswith("/base"):
                m.st_size = size_base
            elif p.startswith("/remote"):
                m.st_size = size_remote
            else:
                raise FileNotFoundError(p)
            return m

        def mkdir(self, p):
            self.dirs.add(p)

        def truncate(self, p, n):
            truncations.append((p, n))

        def remove(self, p):
            pass

        def close(self):
            pass

    class Ssh:
        def open_sftp(self):
            return S()

    return Ssh(), truncations


def test_resume_min_offset_and_truncate_larger():
    ssh, truncations = _ssh_with_sizes(100, 80)
    offset = sftp_pool.prepare_for_upload(ssh, "/base/dir/x", "/remote/dir/x", fresh=False)
    assert offset == 80
    # The bigger side (base, 100) should be truncated down to 80.
    assert ("/base/dir/x", 80) in truncations
    # No need to truncate the smaller side.
    assert ("/remote/dir/x", 80) not in truncations


def test_resume_equal_sizes_no_truncate():
    ssh, truncations = _ssh_with_sizes(42, 42)
    offset = sftp_pool.prepare_for_upload(ssh, "/base/dir/x", "/remote/dir/x", fresh=False)
    assert offset == 42
    assert truncations == []


def test_fresh_removes_existing():
    ssh, _ = _ssh_with_sizes(123, 456)
    offset = sftp_pool.prepare_for_upload(ssh, "/base/dir/x", "/remote/dir/x", fresh=True)
    assert offset == 0
