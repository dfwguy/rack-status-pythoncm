"""DualWriter and path-safety tests using a fake SFTPClient."""
from __future__ import annotations

from io import BytesIO
from unittest.mock import MagicMock

import pytest

from app import sftp_pool


class FakeFile:
    def __init__(self, path: str) -> None:
        self.path = path
        self.buf = BytesIO()
        self.pipelined = False
        self.closed = False

    def write(self, data: bytes) -> None:
        self.buf.write(data)

    def flush(self) -> None:
        pass

    def set_pipelined(self, v: bool) -> None:
        self.pipelined = v

    def close(self) -> None:
        self.closed = True


class FakeSftp:
    def __init__(self) -> None:
        self.files: dict[str, FakeFile] = {}
        self.dirs: set[str] = {"/"}
        self.closed = False

    def stat(self, p):
        if p not in self.dirs and p not in self.files:
            raise FileNotFoundError(p)
        m = MagicMock()
        m.st_size = self.files[p].buf.getbuffer().nbytes if p in self.files else 0
        return m

    def mkdir(self, p):
        self.dirs.add(p)

    def open(self, p, mode):
        f = FakeFile(p)
        self.files[p] = f
        return f

    def close(self):
        self.closed = True


class FakeSsh:
    def __init__(self) -> None:
        self._sftps: list[FakeSftp] = []

    def open_sftp(self):
        s = FakeSftp()
        self._sftps.append(s)
        return s

    def close(self):
        pass


def test_dual_writer_mirrors_writes():
    ssh = FakeSsh()
    w = sftp_pool.DualWriter(ssh, "/base/dir/file.bin", "/remote/dir/file.bin")
    w.write(b"hello ")
    w.write(b"world")
    assert w._fb.buf.getvalue() == b"hello world"
    assert w._fr.buf.getvalue() == b"hello world"
    w.close()
    assert w._fb.closed and w._fr.closed


def test_dual_writer_pipelined():
    ssh = FakeSsh()
    w = sftp_pool.DualWriter(ssh, "/a/x", "/b/x")
    assert w._fb.pipelined
    assert w._fr.pipelined
    w.close()


def test_is_safe_subpath():
    allowed = ["btrfs", "ist", "perf", "diag"]
    assert sftp_pool.is_safe_subpath("btrfs", allowed)
    assert sftp_pool.is_safe_subpath("btrfs/2026-05-11", allowed)
    assert not sftp_pool.is_safe_subpath("etc", allowed)
    assert not sftp_pool.is_safe_subpath("/btrfs", allowed)
    assert not sftp_pool.is_safe_subpath("../btrfs", allowed)
    assert not sftp_pool.is_safe_subpath("btrfs/../diag", allowed)
    assert not sftp_pool.is_safe_subpath("", allowed)


def test_join_path():
    assert sftp_pool.join_path("/partner", "btrfs", "x.bin") == "/partner/btrfs/x.bin"
    assert sftp_pool.join_path("/partner/", "/btrfs/", "/x.bin") == "/x.bin"  # absolute resets
    assert sftp_pool.join_path("/a", "b/c", "d") == "/a/b/c/d"


def _attr(name, *, size=0, mtime=0, is_dir=False):
    a = MagicMock()
    a.filename = name
    a.st_size = size
    a.st_mtime = mtime
    a.st_mode = 0o040755 if is_dir else 0o100644
    return a


def _ssh_with_listings(base_items, remote_items):
    class S:
        def listdir_attr(self, p):
            if p.startswith("/base"):
                return base_items
            if p.startswith("/remote"):
                return remote_items
            raise FileNotFoundError(p)
        def close(self): pass

    class Ssh:
        def open_sftp(_self):
            return S()
    return Ssh()


def test_list_dir_merged_ok_and_mismatches():
    base = [
        _attr("subdir", is_dir=True, mtime=100),
        _attr("aligned.bin", size=1000, mtime=200),
        _attr("partial.bin", size=500,  mtime=210),     # base larger
        _attr("base_only.bin", size=10, mtime=220),
    ]
    remote = [
        _attr("subdir", is_dir=True, mtime=100),
        _attr("aligned.bin", size=1000, mtime=200),
        _attr("partial.bin", size=400, mtime=210),      # remote smaller
        _attr("remote_only.bin", size=11, mtime=230),
    ]
    ssh = _ssh_with_listings(base, remote)
    out = sftp_pool.list_dir_merged(ssh, "/base/btrfs", "/remote/btrfs")
    by_name = {e["name"]: e for e in out}
    assert by_name["subdir"]["sync"] == "ok"
    assert by_name["subdir"]["type"] == "dir"
    assert by_name["aligned.bin"]["sync"] == "ok"
    assert by_name["partial.bin"]["sync"] == "size_mismatch"
    assert by_name["partial.bin"]["base"]["size"] == 500
    assert by_name["partial.bin"]["remote"]["size"] == 400
    assert by_name["base_only.bin"]["sync"] == "base_only"
    assert by_name["remote_only.bin"]["sync"] == "remote_only"
    # Directories sort before files.
    assert out[0]["type"] == "dir"
