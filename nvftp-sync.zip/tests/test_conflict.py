"""Overwrite/rename/error policy when the target filename already exists."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from app import db
from app.config import Config
from app.sftp_pool import ConflictError
from app.upload_manager import UploadManager


def _cfg(policy: str = "error") -> Config:
    c = Config()
    c.endpoints.base = "/base"
    c.endpoints.remote = "/remote"
    c.uploads.on_conflict = policy
    return c


def _fake_ssh_with_existing(base_size, remote_size, *, missing_names=None):
    """ssh that reports the target file exists on both endpoints (configurable per name)."""
    missing_names = set(missing_names or [])
    removed: list[str] = []

    class S:
        def stat(self, p):
            for name in missing_names:
                if p.endswith("/" + name):
                    raise FileNotFoundError(p)
            m = MagicMock()
            if p.startswith("/base"):  m.st_size = base_size
            elif p.startswith("/remote"): m.st_size = remote_size
            else: raise FileNotFoundError(p)
            return m
        def remove(self, p): removed.append(p)
        def mkdir(self, p): pass
        def listdir_attr(self, p): return []
        def close(self): pass

    class Ssh:
        def open_sftp(self): return S()
        def close(self): pass

    return Ssh(), removed


def test_policy_error_raises_conflict():
    cfg = _cfg("error")
    ssh, _ = _fake_ssh_with_existing(100, 100)
    m = UploadManager(cfg, on_progress=lambda _: None)
    with patch("app.upload_manager.connect", return_value=ssh):
        h = m._new_handle(source="browser", filename="x.bin",
                          target_folder="btrfs", total_bytes=100)
        with pytest.raises(ConflictError) as exc:
            m._resolve_conflict(h, policy=None)
    assert exc.value.info["base"]["exists"]
    assert exc.value.info["remote"]["exists"]
    assert exc.value.info["base"]["size"] == 100


def test_policy_overwrite_removes_existing():
    cfg = _cfg("overwrite")
    ssh, removed = _fake_ssh_with_existing(100, 100)
    db.init_db()
    m = UploadManager(cfg, on_progress=lambda _: None)
    with patch("app.upload_manager.connect", return_value=ssh):
        h = m._new_handle(source="browser", filename="x.bin",
                          target_folder="btrfs", total_bytes=100)
        m._resolve_conflict(h, policy=None)
    assert "/base/btrfs/x.bin" in removed
    assert "/remote/btrfs/x.bin" in removed


def test_policy_rename_picks_new_filename():
    cfg = _cfg("rename")
    # x.bin exists; the renamed variant should not exist on either side.
    ssh, removed = _fake_ssh_with_existing(100, 100, missing_names=[])  # everything exists by default

    # Override _fake_ssh: make only 'x.bin' exist; new candidate names don't exist.
    class S:
        def stat(self, p):
            if p.endswith("/x.bin"):
                m = MagicMock(); m.st_size = 100
                return m
            raise FileNotFoundError(p)
        def remove(self, p): pass
        def mkdir(self, p): pass
        def listdir_attr(self, p): return []
        def close(self): pass
    class Ssh:
        def open_sftp(self): return S()
        def close(self): pass

    db.init_db()
    m = UploadManager(cfg, on_progress=lambda _: None)
    with patch("app.upload_manager.connect", return_value=Ssh()):
        h = m._new_handle(source="browser", filename="x.bin",
                          target_folder="btrfs", total_bytes=100)
        m._resolve_conflict(h, policy=None)
    assert h.filename != "x.bin"
    assert h.filename.startswith("x_") and h.filename.endswith(".bin")
    assert h.base_path.endswith("/" + h.filename)
    assert h.remote_path.endswith("/" + h.filename)


def test_policy_no_conflict_does_nothing():
    cfg = _cfg("error")
    class S:
        def stat(self, p): raise FileNotFoundError(p)
        def remove(self, p): pass
        def mkdir(self, p): pass
        def listdir_attr(self, p): return []
        def close(self): pass
    class Ssh:
        def open_sftp(self): return S()
        def close(self): pass

    db.init_db()
    m = UploadManager(cfg, on_progress=lambda _: None)
    with patch("app.upload_manager.connect", return_value=Ssh()):
        h = m._new_handle(source="browser", filename="new.bin",
                          target_folder="btrfs", total_bytes=100)
        m._resolve_conflict(h, policy=None)   # should not raise
    assert h.filename == "new.bin"


def test_policy_per_call_overrides_default():
    cfg = _cfg("error")
    ssh, removed = _fake_ssh_with_existing(100, 100)
    db.init_db()
    m = UploadManager(cfg, on_progress=lambda _: None)
    with patch("app.upload_manager.connect", return_value=ssh):
        h = m._new_handle(source="browser", filename="x.bin",
                          target_folder="btrfs", total_bytes=100)
        # Pass overwrite explicitly even though config default is error.
        m._resolve_conflict(h, policy="overwrite")
    assert "/base/btrfs/x.bin" in removed
