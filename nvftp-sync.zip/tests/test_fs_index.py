"""Persistent SFTP listing index."""
from __future__ import annotations

import time
from pathlib import Path

import pytest

from app.fs_index import FsIndex


@pytest.fixture
def idx(tmp_path: Path) -> FsIndex:
    return FsIndex(tmp_path / "fs_index.sqlite")


def test_put_get_roundtrip(idx: FsIndex):
    payload = {"entries": [{"name": "x.bin"}], "parent": "btrfs"}
    idx.put("btrfs/lot-1", payload)
    hit = idx.get("btrfs/lot-1")
    assert hit is not None
    value, fetched_at = hit
    assert value == payload
    assert fetched_at <= time.time() + 0.1


def test_get_missing_returns_none(idx: FsIndex):
    assert idx.get("never-seen") is None


def test_invalidate_prefix(idx: FsIndex):
    idx.put("", {})
    idx.put("btrfs", {})
    idx.put("btrfs/lot-1", {})
    idx.put("btrfs/lot-1/sub", {})
    idx.put("ist", {})
    n = idx.invalidate_prefix("btrfs/lot-1")
    # btrfs/lot-1 + ancestors (btrfs, "") + descendant btrfs/lot-1/sub = 4
    assert n == 4
    assert idx.get("btrfs/lot-1") is None
    assert idx.get("btrfs/lot-1/sub") is None
    assert idx.get("btrfs") is None
    assert idx.get("") is None
    assert idx.get("ist") is not None


def test_invalidate_root_only(idx: FsIndex):
    idx.put("", {})
    idx.put("btrfs", {})
    n = idx.invalidate_prefix("")
    assert n == 1
    assert idx.get("") is None
    assert idx.get("btrfs") is not None
