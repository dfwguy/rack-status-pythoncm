"""URL puller logic: chunk relay, Range fallback, upstream header parsing."""
from __future__ import annotations

import binascii
from io import BytesIO
from unittest.mock import patch, MagicMock

import pytest

from app import url_puller
from app.hashing import IncrementalSha256


class DummyWriter:
    def __init__(self) -> None:
        self.buf = BytesIO()

    def write(self, data: bytes) -> None:
        self.buf.write(data)

    def flush(self) -> None:
        pass


class DummyResponse:
    def __init__(self, status: int, body: bytes, headers: dict | None = None) -> None:
        self.status_code = status
        self._body = body
        self.headers = headers or {}

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")

    def iter_content(self, chunk_size: int):
        b = self._body
        for i in range(0, len(b), chunk_size):
            yield b[i:i + chunk_size]


def test_basic_pull():
    body = b"the quick brown fox"
    with patch.object(url_puller.requests, "get", return_value=DummyResponse(200, body)):
        w = DummyWriter()
        result = url_puller.pull(url="http://x/y", writer=w)
    assert w.buf.getvalue() == body
    assert result["bytes"] == len(body)


def test_range_resume():
    body = b"second half"  # what upstream returns when Range honored
    with patch.object(url_puller.requests, "get", return_value=DummyResponse(206, body)):
        w = DummyWriter()
        result = url_puller.pull(url="http://x", writer=w, start_offset=11)
    assert w.buf.getvalue() == body
    assert result["bytes"] == len(body)


def test_range_ignored_fallback_discards():
    full = b"AAAAAAAAAA" + b"second half"  # upstream re-sent the whole thing
    with patch.object(url_puller.requests, "get", return_value=DummyResponse(200, full)):
        w = DummyWriter()
        result = url_puller.pull(url="http://x", writer=w, start_offset=10)
    # First 10 bytes should be discarded.
    assert w.buf.getvalue() == b"second half"
    assert result["bytes"] == len(b"second half")


def test_upstream_sha_header_hex():
    sha = "f" * 64
    r = DummyResponse(200, b"data", headers={"X-Checksum-Sha256": sha})
    with patch.object(url_puller.requests, "get", return_value=r):
        result = url_puller.pull(url="http://x", writer=DummyWriter())
    assert result["upstream_sha"] == sha


def test_upstream_sha_header_goog_base64():
    raw = bytes.fromhex("aa" * 32)
    b64 = binascii.b2a_base64(raw, newline=False).decode()
    r = DummyResponse(200, b"data", headers={"X-Goog-Hash": f"sha256={b64},md5=AAAA"})
    with patch.object(url_puller.requests, "get", return_value=r):
        result = url_puller.pull(url="http://x", writer=DummyWriter())
    assert result["upstream_sha"] == "aa" * 32


def test_sha_state_updated():
    body = b"hello"
    state = IncrementalSha256()
    with patch.object(url_puller.requests, "get", return_value=DummyResponse(200, body)):
        url_puller.pull(url="http://x", writer=DummyWriter(), sha_state=state)
    import hashlib
    assert state.hexdigest() == hashlib.sha256(body).hexdigest()


class _FlakyResponse(DummyResponse):
    """Yields the first `cut` bytes, then raises ChunkedEncodingError mid-stream."""

    def __init__(self, status: int, body: bytes, cut: int, headers: dict | None = None) -> None:
        super().__init__(status, body, headers)
        self._cut = cut

    def iter_content(self, chunk_size: int):
        b = self._body
        sent = 0
        for i in range(0, len(b), chunk_size):
            piece = b[i:i + chunk_size]
            if sent + len(piece) > self._cut:
                yield piece[: self._cut - sent]
                import requests as _r
                raise _r.exceptions.ChunkedEncodingError("simulated drop")
            yield piece
            sent += len(piece)


def test_retry_continues_with_range_after_incomplete_read(monkeypatch):
    """Drop mid-stream after 7 bytes, then a second GET with Range serves the rest."""
    full = b"AAAAAAA" + b"BBBBBBBB"  # 7 + 8 = 15 bytes total
    calls: list[dict] = []

    def fake_get(url, **kwargs):
        calls.append({"headers": kwargs.get("headers", {}), "n": len(calls)})
        if len(calls) == 1:
            return _FlakyResponse(200, full, cut=7, headers={"Content-Length": str(len(full))})
        # Second call honors Range, returns only the remaining 8 bytes.
        return DummyResponse(206, b"BBBBBBBB",
                             headers={"Content-Length": "8", "Content-Range": "bytes 7-14/15"})

    monkeypatch.setattr(url_puller.requests, "get", fake_get)
    monkeypatch.setattr(url_puller.time, "sleep", lambda *_: None)

    w = DummyWriter()
    state = IncrementalSha256()
    result = url_puller.pull(url="http://x", writer=w, sha_state=state, chunk_size=4)
    assert w.buf.getvalue() == full
    assert result["bytes"] == 15
    assert calls[1]["headers"].get("Range") == "bytes=7-"

    import hashlib
    assert state.hexdigest() == hashlib.sha256(full).hexdigest()


def test_retry_exhausted_propagates(monkeypatch):
    import requests as _r
    monkeypatch.setattr(url_puller.requests, "get",
                        lambda *a, **k: _FlakyResponse(200, b"ABCDEFGHIJ", cut=2,
                                                      headers={"Content-Length": "10"}))
    monkeypatch.setattr(url_puller.time, "sleep", lambda *_: None)
    with pytest.raises(_r.exceptions.ChunkedEncodingError):
        url_puller.pull(url="http://x", writer=DummyWriter(), max_retries=2, chunk_size=4)
