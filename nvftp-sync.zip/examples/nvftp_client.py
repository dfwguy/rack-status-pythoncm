#!/usr/bin/env python3
"""Minimal client for the nvftp-sync REST API.

Usage:
    # Pull a URL into btrfs/
    python nvftp_client.py url https://example.com/big.tbz btrfs

    # Submit a local file path (server-side) into diag/2026-05-11
    python nvftp_client.py local /path/to/file.bin diag/2026-05-11

    # Stream-upload a local file from this script into perf/
    python nvftp_client.py upload /path/to/file.bin perf

    # Wait for a job
    python nvftp_client.py wait <upload_id>

The base URL defaults to http://127.0.0.1:5050 and the token is read from
the NVFTP_TOKEN env var or data/.api_token next to this script (when colocated).
Loopback requests can skip the token entirely (see allow_loopback_no_auth).
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import requests


def _resolve_token() -> str | None:
    t = os.environ.get("NVFTP_TOKEN")
    if t:
        return t
    candidates = [
        Path.cwd() / "data" / ".api_token",
        Path(__file__).resolve().parent.parent / "data" / ".api_token",
    ]
    for p in candidates:
        if p.exists():
            return p.read_text().strip()
    return None


def _headers(token: str | None) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"} if token else {}


def submit_url(base: str, token: str | None, url: str, target: str, verify_tls: bool) -> str:
    r = requests.post(
        f"{base}/api/v1/uploads",
        headers={**_headers(token), "Content-Type": "application/json"},
        json={"source": "url", "url": url, "target_folder": target, "verify_tls": verify_tls},
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["upload_id"]


def submit_local(base: str, token: str | None, path: str, target: str) -> str:
    r = requests.post(
        f"{base}/api/v1/uploads",
        headers={**_headers(token), "Content-Type": "application/json"},
        json={"source": "local_path", "local_path": path, "target_folder": target},
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["upload_id"]


def upload_multipart(base: str, token: str | None, path: str, target: str) -> str:
    with open(path, "rb") as f:
        r = requests.post(
            f"{base}/api/v1/uploads/file",
            headers=_headers(token),
            files={"file": (Path(path).name, f, "application/octet-stream")},
            data={"target_folder": target},
            timeout=None,
        )
    r.raise_for_status()
    return r.json()["upload_id"]


def wait(base: str, token: str | None, upload_id: str, interval: float = 1.5) -> dict:
    last_status = None
    while True:
        r = requests.get(f"{base}/api/v1/uploads/{upload_id}", headers=_headers(token), timeout=10)
        r.raise_for_status()
        row = r.json()
        if row["status"] != last_status:
            print(f"[{upload_id[:8]}] {row['status']:10s} bytes={row['bytes_done']}", flush=True)
            last_status = row["status"]
        if row["status"] in ("complete", "failed", "corrupt"):
            return row
        time.sleep(interval)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=os.environ.get("NVFTP_URL", "http://127.0.0.1:5050"))
    ap.add_argument("--token", default=_resolve_token())
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("url"); p.add_argument("url"); p.add_argument("target")
    p.add_argument("--insecure", action="store_true", help="skip upstream TLS verification")

    p = sub.add_parser("local"); p.add_argument("path"); p.add_argument("target")
    p = sub.add_parser("upload"); p.add_argument("path"); p.add_argument("target")
    p = sub.add_parser("wait"); p.add_argument("upload_id")
    p = sub.add_parser("status"); p.add_argument("upload_id")

    args = ap.parse_args()

    if args.cmd == "url":
        uid = submit_url(args.base, args.token, args.url, args.target, verify_tls=not args.insecure)
        print(uid)
        wait(args.base, args.token, uid)
    elif args.cmd == "local":
        uid = submit_local(args.base, args.token, args.path, args.target)
        print(uid)
        wait(args.base, args.token, uid)
    elif args.cmd == "upload":
        uid = upload_multipart(args.base, args.token, args.path, args.target)
        print(uid)
        wait(args.base, args.token, uid)
    elif args.cmd == "wait":
        wait(args.base, args.token, args.upload_id)
    elif args.cmd == "status":
        r = requests.get(f"{args.base}/api/v1/uploads/{args.upload_id}", headers=_headers(args.token))
        print(r.text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
