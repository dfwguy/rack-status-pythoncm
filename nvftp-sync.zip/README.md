# nvftp-sync

A local web app that uploads very large files (up to 100 GB) to the NVIDIA
`transfer.nvftp.nvidia.com` SFTP endpoint and writes every byte to **two
mirrored paths in lock-step** — so the base and the remote partner spaces
stay in sync without a separate rsync step.

Features:
- **Three ingestion paths**: browser drag-drop, server-side URL pull
  (`wget`-style), and a scriptable REST API for other tools.
- **16 MiB chunked HTTP uploads** with pause / resume / stop, exponential-
  backoff retry on network drops, and crash-safe SQLite-backed state.
- **End-to-end SHA-256**: the browser hashes locally while uploading; the
  server hashes what it writes; URL pulls also cross-check upstream
  `X-Checksum-Sha256` / `X-Goog-Hash` headers when present.
- **Concurrent uploads** with a configurable cap.
- **Cross-platform** — Python 3.10+ on Ubuntu, macOS, and Windows.

## Quick start

```bash
git clone <repo>
cd nvftp-sync
cp config.example.yaml config.yaml         # edit endpoints, key path, etc.
./run.sh                                   # Ubuntu / macOS
# or
run.bat                                    # Windows
```

The app binds to `http://127.0.0.1:5050` by default and pops the browser
open. No login screen — it reads your local SSH key (`~/.ssh/id_ed25519`
by default).

## Configuration

See `config.example.yaml`. The key fields:

| Key | Purpose |
|---|---|
| `sftp.host` / `sftp.username` / `sftp.key_path` | How to reach the SFTP server |
| `endpoints.base` / `endpoints.remote` | The two mirrored target paths |
| `allowed_folders` | Top-level folders the UI lets you target (`btrfs`, `ist`, `perf`, `diag`) |
| `uploads.max_concurrent` | How many uploads can run in parallel |
| `uploads.bandwidth_limit_kbps` | Per-upload throttle, `0` = unlimited |
| `url_pull.trusted_skip_verify_hosts` | Hosts where TLS verification can be skipped by default |
| `server.allow_loopback_no_auth` | If true, scripts on the same host bypass the API token |

## REST API (`/api/v1`)

External scripts can submit uploads programmatically. Pass
`Authorization: Bearer <token>` — token is auto-generated on first run
into `data/.api_token`. Loopback requests skip the check when
`allow_loopback_no_auth` is true.

```bash
# 1) Pull a URL into btrfs/  (server-side download)
curl -X POST http://127.0.0.1:5050/api/v1/uploads \
  -H 'Content-Type: application/json' \
  -d '{
    "source": "url",
    "url": "https://storage.smartfarm.nvidia.com/.../file.tbz",
    "target_folder": "btrfs",
    "verify_tls": false
  }'

# 2) Submit a local path the server can read (no upload bytes)
curl -X POST http://127.0.0.1:5050/api/v1/uploads \
  -H 'Content-Type: application/json' \
  -d '{"source":"local_path","local_path":"/data/file.bin","target_folder":"diag/2026-05-11"}'

# 3) Stream-upload from the script (multipart)
curl -X POST http://127.0.0.1:5050/api/v1/uploads/file \
  -F file=@/data/file.bin -F target_folder=perf

# 4) Watch progress
curl http://127.0.0.1:5050/api/v1/uploads/<upload_id>
curl -N http://127.0.0.1:5050/api/v1/uploads/<upload_id>/events     # SSE stream

# 5) Pause / resume / stop
curl -X POST http://127.0.0.1:5050/api/v1/uploads/<upload_id>/pause
```

A working Python client is at [`examples/nvftp_client.py`](examples/nvftp_client.py):

```bash
python examples/nvftp_client.py url   https://example.com/x.tbz btrfs
python examples/nvftp_client.py local /path/to/file.bin diag/2026-05-11
python examples/nvftp_client.py upload /path/to/file.bin perf
```

## How it works

```
Browser   ──HTTP chunks──┐
URL pull  ──requests.get─┤   Flask + SocketIO (127.0.0.1:5050)
Local API ───────────────┤
                         │
                         └──▶  DualWriter  ──┬──▶ /partner-space/fii-foxconn.com/yl-fs-pipeline/…
                                              └──▶ /partner-space/wistron.com/fusion-fs-pipeline/…
```

- One SSH connection per upload (single SFTP host), two `SFTPClient.open()`
  handles writing in append-mode with `set_pipelined(True)` for throughput.
- Every chunk acked → SQLite row updated, so power-loss survives.
- On startup, any row left in `uploading` is moved to `paused` and shown in
  the UI with a Resume button.
- Resume reconciles `min(stat_size(base), stat_size(remote))`, truncates the
  larger side, and continues from there.

## Project layout

```
app/                Flask app, routes, SFTP pool, upload manager, URL puller
static/             CSS (NVIDIA dark theme), JS (chunker, hasher, progress)
templates/          Jinja templates
examples/           Python client demo
tests/              Pytest suite (no SFTP needed — uses mocks)
config.example.yaml Documented config
run.sh / run.bat    Cross-platform launchers
```

## Tests

```bash
pip install -r requirements.txt
pytest
```

## Security notes

- The app binds to `127.0.0.1` by default. **Do not** flip to `0.0.0.0`
  unless you understand the implications — the SFTP key on your machine
  becomes a relay-write capability for anyone who can reach the port.
- The API token is a 32-byte URL-safe random string saved to
  `data/.api_token` with `0600` permissions. Treat it like a password.
- TLS-verify skip for URL pulls is opt-in per request, or pre-approved via
  the `trusted_skip_verify_hosts` allow-list. Use only with hosts whose
  certificate situation you understand.
