#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# 1. Ensure the environment exists
if [ ! -f ".venv/bin/activate" ]; then
    echo "Environment missing or broken. Rebuilding..."
    rm -rf .venv
    python3 -m venv .venv
fi

# 2. Activate (The "shellcheck" line tells the linter to ignore the local path)
# shellcheck disable=SC1091
source .venv/bin/activate

# 3. Handle dependencies (Only if missing or requirements.txt is newer)
if [[ ! -f .venv/.deps_installed || requirements.txt -nt .venv/.deps_installed ]]; then
  echo "Syncing dependencies..."
  pip install --upgrade pip >/dev/null
  pip install -r requirements.txt
  touch .venv/.deps_installed
fi

# 4. Launch
exec python -m app "$@"